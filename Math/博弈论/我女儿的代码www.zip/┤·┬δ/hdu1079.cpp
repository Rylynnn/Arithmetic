#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		int year,month,day;
		cin>>year>>month>>day;
		if ((month+day)%2==0||month==9&&day==30||month==11&&day==30) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}
