#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int mmap[1100][1100],n,k;
bool flag[1100];
int ret;
int solve(int m)
{
	for (int i=1;i<=n;i++)
	{
		if (mmap[m][i]&&!flag[i])
		{
			flag[m]=true;
			if (!solve(i))
			{
				flag[m]=false;
				ret=i;
				return true;
			}
			flag[m]=false;
		}
	}
	return false;
}
int main()
{
	while (scanf("%d %d",&n,&k)==2)
	{
		memset(mmap,0,sizeof(mmap));
		for (int i=1;i<n;i++)
		{
			int u,v;
			scanf("%d %d",&u,&v);
			mmap[u][v]=mmap[v][u]=1;
		}
		memset(flag,false,sizeof(flag));
		int ans=solve(k);
		if (ans==0) puts("First player loses");
		else printf("First player wins flying to airport %d \n",ret);
	}
	return 0;
}
