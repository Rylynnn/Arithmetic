#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int n;
	while (scanf("%d",&n)==1)
	{
		if (n%3==0) printf("Cici\n");
		else printf("Kiki\n");
	}
	return 0;
}
