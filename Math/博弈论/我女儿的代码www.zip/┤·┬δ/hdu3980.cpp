#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int n,m;
int sg[1100];
int SG(int x)
{
	if (sg[x]!=-1) return sg[x];
	int vis[1100];
	memset(vis,0,sizeof(vis)); 
	for (int j=1;j<=x-m+1;j++)
	{
		if (sg[j-1]==-1) sg[j-1]=SG(j-1);
		if (sg[x-(j+m-1)]==-1) sg[x-(j+m-1)]=SG(x-(j+m-1));
		vis[sg[j-1]^sg[x-(j+m-1)]]=1;
	}
    for (int i=0;;i++)
    {
		if (vis[i]==0) return i;
	}
}	
int main()
{
	int T;
	cin>>T;
	int cas=0;
	while (T--)
	{
		scanf("%d %d",&n,&m);
		if (m>n)
		{
			printf("Case #%d: ",++cas);
			printf("abcdxyzk\n");
			continue;
		}
		memset(sg,-1,sizeof(sg));
		n-=m;
		printf("Case #%d: ",++cas);
		if (SG(n)) printf("abcdxyzk\n");
		else printf("aekdycoin\n");
		
	}
	return 0;
}
