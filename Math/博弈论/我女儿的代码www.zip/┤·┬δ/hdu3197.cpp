#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;

int e[2100],pre[2100],last[2100];
int rt[1100];
int n;
int SG(int x)
{
	int res=0;
	for (int i=last[x];i!=0;i=pre[i])
	{
		res^=SG(e[i])+1;
	}
	return res;
}
int main()
{
	while (scanf("%d",&n)==1)
	{
		memset(rt,0,sizeof(rt));
		int res=0;
		for (int i=1;i<=n;i++)
			last[i]=0;		
		for (int i=1;i<=n;i++)
		{
			int x;
			scanf("%d",&x);
			if (x!=-1)
			{
				e[i]=i;
				pre[i]=last[x+1];
				last[x+1]=i;
			}
			else rt[i]=1;
		}
		for (int i=1;i<=n;i++)
			if (rt[i]) res^=SG(i);
		if (res) puts("YES");
		else puts("NO");
	}
	return 0;
}
