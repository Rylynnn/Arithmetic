
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int sg[110000];
int a[1100];
int n,t,m;
int SG(int x)
{
	if (sg[x]!=-1) return sg[x];
	int b[110],num=0;
	b[1]=-1;
	for (int i=1;i<=n;i++)
	{
		if (x-a[i]>=0)
		{
			num++;
			b[num]=SG(x-a[i]);
		}
	}
	b[num+1]=-1;
	sort(b+1,b+1+num);
	int last=0,pos=1;
	while(1)
	{
		if (b[pos]!=last||pos>num)
		{
			sg[x]=last;
			break;
		}
		while(b[pos]==last&&pos<=num) pos++;
		last++;
	}
	 
	return sg[x];
}
int main()
{
	while(scanf("%d",&n)==1&&n)
	{
		memset(sg,-1,sizeof(sg));
		sg[0]=0;
		for (int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		scanf("%d",&t);
		for (int i=1;i<=t;i++)
		{
			int res=0;
			scanf("%d",&m);
			for (int j=1;j<=m;j++)
			{
				int x;
				scanf("%d",&x);
				res^=SG(x);
			}
			if (res) printf("W");
			else printf("L");
		}
		printf("\n");
	}
	return 0;
}
