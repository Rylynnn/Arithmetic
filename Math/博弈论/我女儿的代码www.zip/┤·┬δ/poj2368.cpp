#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int a[110000];
int num;
int main()
{
	int k;
	cin>>k;
	for (int i=1;i*i<=k;i++)
	{
		if (k%i==0)
		{
			num++;
			a[num]=i;
			num++;
			a[num]=k/i;
		}
	}
	sort(a+1,a+1+num);
	for (int i=1;i<=num;i++)
		if (a[i]>2)
		{
			cout<<a[i]-1<<endl;
			return 0;
		}
	cout<<0<<endl;
	return 0;
}
