#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;
int sg[55][55];
int n,m;
int pp[11000];
int SG(int x,int y)
{
	memset(pp,0,sizeof(pp));
	for (int i=0;i<x;i++)
		for (int j=0;j<y;j++)
		{
			pp[sg[x][j]^sg[i][y]]=1;
		}
	for (int i=0;;i++)
	{
		if (!pp[i]) return i;
	}
}
int main()
{
	memset(sg,-1,sizeof(sg));
	for (int i=0;i<55;i++)
	{
		sg[0][i]=sg[i][0]=i;
	}
	for (int i=1;i<55;i++)
	  	for (int j=1;j<55;j++)
	 	{
			sg[i][j]=SG(i,j);
	 	}
	
	while (1)
	{
		cin>>n>>m;
		if (n==0&&m==0) break;
		int res=0;	
		for (int i=0;i<n;i++)
		{
			string s;
			cin>>s;
			for (int j=0;j<m;j++)
			{
				if (s[j]=='#') res^=sg[i][j];
			}
		}
		if (res) printf("John\n");
		else printf("Jack\n");
	}
	return 0;
}
