#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std;
int n,p,q;
int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}
bool cal(int n,int p,int q)
{
    return n%p<q && n%p%(p-q)==0;
}
int main()
{
    int T;
    for(cin>>T;T;T--)
    {
        scanf("%d%d%d",&p,&q,&n);
        int d=gcd(p,q);
        if(n%d)
        {
            puts("R");
            continue;
        }
        p/=d;q/=d;n/=d;
        if(p==q)
            puts("E");
        else if(p>q)
        {
            if(n<p) puts("P");
            else if (cal(n,p,q)) puts("E");
			else puts("P");
        }
        else
        {
            if(n<p)
            {
                if(n+p<q) puts("E");
                else if (cal(n+p,q,p)) puts("P");
				else puts("E");
            }
            else puts("E");
        }
    }
    return 0;
}
