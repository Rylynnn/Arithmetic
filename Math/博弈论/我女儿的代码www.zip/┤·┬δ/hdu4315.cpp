#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int n,k,a[10000],tmp,res;
int main()
{
    while(scanf("%d%d",&n,&k)!=-1)
    {
        a[0]=-1;
        for(int i=1;i<=n;i++)
            scanf("%d",&a[i]);
        if(k==1)
        {
            printf("Alice\n");
            continue;
        }
        res=0;
        for(int i=n;i>0;i-=2)
            res^=(tmp=a[i]-a[i-1]-1);
        if(n%2==1&&k==2)
            res=res^(tmp-1)^tmp;
        if(res==0)
            printf("Bob\n");
        else
            printf("Alice\n");
    }
    return 0;
}
