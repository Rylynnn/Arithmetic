#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int sg[30][8100];
int a[30];
int n,s;
int SG(int x,int y)
{
	if (sg[x][y]!=-1) return sg[x][y];
	for (int i=1;i<=a[x];i++)
	{
		int t=y-i;
		if (t<0) break;
		int d;
		if (x+1>=2*n) d=0;
		else d=x+1;
		if (!SG(d,t)) return sg[x][y]=1;
	}
	return sg[x][y]=0;
} 
int main()
{
	while (scanf("%d",&n)==1&&n)
	{
		scanf("%d",&s);
		for (int i=0;i<2*n;i++)
			scanf("%d",&a[i]);
		memset(sg,-1,sizeof(sg));
		for (int i=0;i<2*n;i++)
			sg[i][0]=1;
		int ans=SG(0,s);
		if (ans==0) puts("0");
		else puts("1");
	}
	return 0;
}	
