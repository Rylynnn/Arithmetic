#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
struct abcd{
	int to,next;
}table[20200];
int head[5050],tot;
int m,n,n1,n2;
char map[110][110];
int pos[110][110];
bool ans[2][5050];
void Add(int x,int y)
{
	table[++tot].to=y;
	table[tot].next=head[x];
	head[x]=tot;
}
namespace Bipartite_Graph_Maximum_Match{
	int result[5050];
	bool state[5050],lonely[5050];
	bool Hungary(int x)
	{
		int i;
		for(i=head[x];i;i=table[i].next)
		{
			if(state[table[i].to])
				continue;
			state[table[i].to]=1;
			if( !result[table[i].to] || Hungary(result[table[i].to]) )
			{
				result[table[i].to]=x;
				return true;
			}
		}
		return false;
	}
	void DFS(int x,bool ans[])
	{
		int i;
		ans[x]=true;
		for(i=head[x];i;i=table[i].next)
			if(!ans[result[table[i].to]])
				DFS(result[table[i].to],ans);
	}
}
using namespace Bipartite_Graph_Maximum_Match;
void Initialize()
{
	memset(head,0,sizeof head);
	tot=0;
	memset(result,0,sizeof result);
	memset(lonely,0,sizeof lonely);
}
int main()
{

	static const int dx[]={0,0,1,-1};
	static const int dy[]={1,-1,0,0};
	int i,j,k;
	cin>>m>>n;
	for(i=1;i<=m;i++)
	{
		scanf("%s",map[i]+1);
		for(j=1;j<=n;j++)
			if(map[i][j]=='.')
				pos[i][j]=++(i+j&1?n1:n2);
	}

	for(i=1;i<=m;i++)
		for(j=1;j<=n;j++)
			if( i+j&1 && map[i][j]=='.' )
				for(k=0;k<4;k++)
				{
					int x=i+dx[k];
					int y=j+dy[k];
					if(x<=0||y<=0||x>m||y>n||map[x][y]=='#')
						continue;
					Add(pos[i][j],pos[x][y]);
				}
	int matches=0;
	for(i=1;i<=n1;i++)
	{
		memset(state,0,sizeof state);
		if( Hungary(i) )
			matches++;
		else
			lonely[i]=true;
	}
	if( matches==n1 && matches==n2 )
		return cout<<"LOSE"<<endl,0;
	for(i=1;i<=n1;i++)
		if(lonely[i])
			DFS(i,ans[1]);

	Initialize();

	for(i=1;i<=m;i++)
		for(j=1;j<=n;j++)
			if( ~(i+j)&1 && map[i][j]=='.' )
				for(k=0;k<4;k++)
				{
					int x=i+dx[k];
					int y=j+dy[k];
					if(x<=0||y<=0||x>m||y>n||map[x][y]=='#')
						continue;
					Add(pos[i][j],pos[x][y]);
				}
	for(i=1;i<=n2;i++)
	{
		memset(state,0,sizeof state);
		if( !Hungary(i) )
			lonely[i]=1;
	}
	for(i=1;i<=n2;i++)
		if(lonely[i])
			DFS(i,ans[0]);

	cout<<"WIN"<<endl;
	for(i=1;i<=m;i++)
		for(j=1;j<=n;j++)
			if( map[i][j]=='.' && ans[i+j&1][pos[i][j]] )
				printf("%d %d\n",i,j);
	return 0;
}

