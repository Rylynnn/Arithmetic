#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int a[10];
int main()
{
	int n;
	while(1)
	{
		scanf("%d",&n);
		if (!n) break;
		for (int i=0;i<n;i++)
			scanf("%d",&a[i]);
		sort(a,a+n);
		int ans=0;
		if (n&1) puts("1");
		else
		{
			for (int i=0;i<n;i+=2)
				if (a[i]!=a[i+1])
					ans=1;
			printf("%d\n",ans);
		}
	}
	return 0;
}
