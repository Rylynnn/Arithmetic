#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	while (1)
	{
		int n;
		scanf("%d",&n);
		if (n==0) break;
		if (n<3) printf("Alice\n");
		else printf("Bob\n");
	}
	return 0;
}
