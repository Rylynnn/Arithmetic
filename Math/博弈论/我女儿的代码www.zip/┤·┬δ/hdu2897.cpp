#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int n,p,q;
int main()
{
	while (scanf("%d %d %d",&n,&p,&q)==3)
	{
		n%=p+q;
		if (n==0||n>p) printf("WIN\n");
		else printf("LOST\n");
	}
	return 0;
}
