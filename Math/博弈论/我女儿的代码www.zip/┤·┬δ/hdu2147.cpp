#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;

int main()
{
	int n,m;
	while (1)
	{
		scanf("%d %d",&n,&m);
		if (!n&&!m) break;
		if ((n&1)&&(m&1)) printf("What a pity!\n");
		else printf("Wonderful!\n");
	}
	return 0;
}
