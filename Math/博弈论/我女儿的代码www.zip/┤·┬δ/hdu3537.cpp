#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;

int n,a[110];

int main()
{
	int flag,len,num,x;
	while (scanf("%d",&n)!=EOF)
	{
		flag=0;
		if (n==0)
		{
			printf("Yes\n");
			continue;
		}
		for (int i=0;i<n;i++)
			scanf("%d",&a[i]);
		sort(a,a+n);
		len=0;
		a[len++]=a[0];
		for (int i=1;i<n;i++)
		    if (a[i]!=a[len-1])
		  		a[len++]=a[i];
		for (int i=0;i<len;i++)
		{
			num=0;
			x=a[i]*2;
			while (a[i])
			{
				if (a[i]&1)  num++;
				a[i]=a[i]>>1;
			}
			if (num%2==0)  x++;
			flag=flag^x;
		}
		if (flag) printf("No\n");
		else printf("Yes\n");
	}
	return 0;
}
