#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int n,x;
int main()
{
	while (cin>>n)
	{
		int res=0;
		for (int i=1;i<=n;i++)
		{
			scanf("%d",&x);
			res^=x;
		}
		if (res) printf("Yes\n");
		else printf("No\n");
	}
	return 0;
}
	
