#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;

int sg[2100];
int SG(int x)
{
	if (sg[x]!=-1) return sg[x];
	int vis[2100];
	memset(vis,0,sizeof(vis));
	for (int i=1;i<=x;i++)
	{
		int t1=0,t2=0;
		if (x-i-2>=0) t1=SG(x-i-2);
		if (i-3>=0) t2=SG(i-3);
		vis[t1^t2]=1;
	}
	for (int i=0;;i++)
		if (!vis[i]) return sg[x]=i;
}
int main()
{
	int n;
	memset(sg,-1,sizeof(sg));
	while (scanf("%d",&n)==1)
	{
		if (SG(n)) puts("1");
		else puts("2");
	}
	return 0;
}
