#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int a[2000000],b[2000000];
int main()
{
	int n,k;
	int T=0,cas=0;
	cin>>T;
	while (T--)
	{
		scanf("%d %d",&n,&k);
		a[0]=b[0]=1;
		int i=0,j=0;
		while (n>a[i])
		{
			i++;
			a[i]=b[i-1]+1;
			while (a[j+1]*k<a[i]) j++;
			if (k*a[j]<a[i]) b[i]=b[j]+a[i];
			else b[i]=a[i];
		}
		cas++;
		printf("Case %d: ",cas);
	    if (n==a[i]) printf("lose\n");
	    else
	    {
			int ans;
			while (n)
			{
				if (n>=a[i])
				{
					n-=a[i];
					ans=a[i];
				}
				i--;
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
