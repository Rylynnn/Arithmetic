#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int n,m;
int main()
{
	while(scanf("%d %d",&n,&m)==2)
	{
		int res=0;
		for (int i=1;i<=n;i++)
		{
			int x,y;
			scanf("%d %d",&x,&y);
			res^=abs(y-x)-1;
		}
		if (res) printf("I WIN!\n");
		else printf("BAD LUCK!\n");
	}
	return 0;
}
