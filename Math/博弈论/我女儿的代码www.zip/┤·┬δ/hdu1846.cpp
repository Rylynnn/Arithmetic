#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		int x,y;
		scanf("%d %d",&x,&y);
		if (x%(y+1)==0) printf("second\n");
		else printf("first\n");
	}
	return 0;
}
