#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<set>
#include<map>
#include<queue>
#include<stack>
#include<vector>
#include<bitset>

using namespace std;
int ans;
int f[1<<21];
int nu[21];
int way[20];
int dd;
int cal()
{
	int ans=0;
	for (int i=0;i<20;i++)
	    ans=ans*2+way[i];
	return ans;
}
int pp[21];
int n;
int main()
{
	int T;
	nu[19]=1;
	for (int i=18;i>=0;i--)
		nu[i]=nu[i+1]*2;
	for (int i=0;i<(1<<21);i++)
	{
		int last=20;
		int x=i;
		for (int j=19;j>=0;j--)
			way[j]=x%2,x/=2;
		memset(pp,0,sizeof(pp));
		for (int j=19;j>=0;j--)
		{
			if (way[j]==0) last=j;
			else
			{
				if (last==20) continue;
				int d=i-nu[j]+nu[last];
				pp[f[d]]=1;
			}
		}
		for (int j=0;j<=20;j++)
			if (!pp[j])
			{
				f[i]=j;
				break;
			}
	}
	scanf("%d",&T);
	
	while (T--)
	{
		scanf("%d",&n);
		ans=0;
		for (int i=1;i<=n;i++)
		{
			memset(way,0,sizeof(way));
			int x;
			scanf("%d",&x);
			for (int j=1;j<=x;j++)
			{
				int y;
				scanf("%d",&y);
				way[y-1]=1;
			}
			dd=cal();
			ans^=f[dd];
		}
		if (ans) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}
