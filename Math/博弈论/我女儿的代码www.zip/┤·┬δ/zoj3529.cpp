#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<cmath>

using namespace std;
#define maxn 6000000
bool valid[maxn];
int primm;
int prim[maxn];
int f[maxn];
void getPrime(int n)
{
	memset(valid,true,sizeof(valid));
	for (int i=2;i<=n;i++)
	{
		if (valid[i])
		{
			f[i]=1;
			primm++;
			prim[primm]=i;
			for (int j=2;j<=n/i;j++)
			{
				int x=i*j;
				while (x%i==0)
				{
					f[i*j]++,x/=i;
				}
				valid[i*j]=0;
			}
			
		}
	}
}
int a[110000];
int main()
{
	getPrime(5000000);
	int n;
	int cas=0;
	while (scanf("%d",&n)==1)
	{
		int res=0;
		for (int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			res^=f[a[i]];
		}
		printf("Test #%d: ",++cas);
		if (res)
		{
			printf("Alice ");
			for (int i=1;i<=n;i++)
			{
				if ((res^f[a[i]])<=f[a[i]])
				{
					printf("%d\n",i);
					break;
				}
			}
		}
		else printf("Bob\n");
	}
	return 0;
}
