#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
bool dp[301][301][301];
int main()
{
	for (int i=0;i<=300;i++)
		for (int j=0;j<=300;j++)
			for (int k=0;k<=300;k++)
			{
				if(!dp[i][j][k])
				{
                    for(int r=1;r+i<=300;r++)
                        dp[i+r][j][k]=1;
                    for(int r=1;r+j<=300;r++)
                        dp[i][j+r][k]=1;
                    for(int r=1;r+k<=300;r++)
                        dp[i][j][k+r]=1;
                    for(int r=1;r+j<=300&&r+i<=300;r++)
                        dp[i+r][j+r][k]=1;
                    for(int r=1;r+j<=300&&r+k<=300;r++)
                        dp[i][j+r][k+r]=1;
                    for(int r=1;r+k<=300&&r+i<=300;r++)
                        dp[i+r][j][k+r]=1;
                }
			}
	int x,y,z;
	while (scanf("%d %d %d",&x,&y,&z)==3)
	{
		printf("%d\n",dp[x][y][z]);
	}
	return 0;
}
