#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int a[110000];
int main()
{
	int n;
	while(scanf("%d",&n)==1)
	{
		for (int i=0;i<n;i++)
			scanf("%d",&a[i]);
		sort(a,a+n);
		int ans=0;
		if (n&1) puts("first player");
		else
		{
			for (int i=0;i<n;i+=2)
				if (a[i]!=a[i+1])
					ans=1;
			if (ans) puts("first player");
			else puts("second player");
		}
	}
	return 0;
}
