#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;

int pp[110000];
int e[210000],pre[210000],last[210000];
int n;
int SG(int x)
{
	pp[x]=1;
	int res=0;
	for (int i=last[x];i!=0;i=pre[i])
	{
		if (!pp[e[i]])	res^=SG(e[i])+1;
	}
	return res;
}
int main()
{
	int T;
	scanf("%d",&T);
	while (T--)
	{
		memset(pp,0,sizeof(pp));
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
			last[i]=0;		
		for (int i=1;i<=n-1;i++)
		{
			int x,y;
			scanf("%d %d",&x,&y);
			e[2*i]=y;
			pre[2*i]=last[x];
			last[x]=2*i;
			e[2*i+1]=x;
			pre[2*i+1]=last[y];
			last[y]=2*i+1;
		}
		if (SG(1)) printf("Alice\n");
		else printf("Bob\n");
	}
	return 0;
}
