#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;

int pp[110];
int e[210],pre[210],last[210];
int n;
int SG(int x)
{
	pp[x]=1;
	int res=0;
	for (int i=last[x];i!=0;i=pre[i])
	{
		if (!pp[e[i]])	res^=SG(e[i])+1;
	}
	return res;
}
int main()
{
	int t;
	while (scanf("%d",&t)==1)
	{
		int res=0;
		int flag=0;
		for (int i=1;i<=t;i++)
		{
			memset(pp,0,sizeof(pp));
			scanf("%d",&n);
			for (int i=1;i<=n;i++)
				last[i]=0;		
			for (int i=1;i<=n-1;i++)
			{
				int x,y;
				scanf("%d %d",&x,&y);
				e[2*i]=y;
				pre[2*i]=last[x];
				last[x]=2*i;
				e[2*i+1]=x;
				pre[2*i+1]=last[y];
				last[y]=2*i+1;
			}
			int t=SG(1);
			if (t>1) flag=1;
			res^=t;
		}
		if ((res&&flag)||(!res&&!flag)) puts("PP");
		else puts("QQ");
	}
	return 0;
}
