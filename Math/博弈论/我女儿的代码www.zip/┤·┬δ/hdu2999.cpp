#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int n,m,k;
int sg[1100];
int f[110];
int cnt;
int SG(int x)
{
	if (sg[x]!=-1) return sg[x];
	int vis[11000];
	memset(vis,0,sizeof(vis)); 
	for (int i=1;i<=cnt;i++)
	{
		if (x-f[i]>=0)
		{
			for (int j=1;j<=x-f[i]+1;j++)
			{
				if (sg[j-1]==-1) sg[j-1]=SG(j-1);
				if (sg[x-(j+f[i]-1)]==-1) sg[x-(j+f[i]-1)]=SG(x-(j+f[i]-1));
				vis[sg[j-1]^sg[x-(j+f[i]-1)]]=1;
			}
		}
		else break;
	}
    for (int i=0;;i++)
    {
		if (vis[i]==0) return i;
	}
}
int main()
{
	while (scanf("%d",&n)==1)
	{
		memset(sg,-1,sizeof(sg));
		sg[0]=0;
		for (int i=1;i<=n;i++)
			scanf("%d",&f[i]);
		sort(f+1,f+1+n);
		cnt=1;
		for (int i=2;i<=n;i++)
		{
			if (f[i]!=f[cnt-1]) f[++cnt]=f[i];
		}
		scanf("%d",&m);
		for (int i=1;i<=m;i++)
		{
			scanf("%d",&k);
			if (sg[k]==-1) sg[k]=SG(k);
			if (sg[k]) puts("1");
			else puts("2");
		}
		
	}
	return 0;
}
