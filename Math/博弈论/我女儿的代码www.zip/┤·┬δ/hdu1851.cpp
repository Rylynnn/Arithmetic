#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;

int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		int n;
		scanf("%d",&n);
		int res=0;
		for (int i=1;i<=n;i++)
		{
			int x,y;
			scanf("%d %d",&x,&y);
			res^=x%(y+1);
		}
		if (res) printf("No\n");
		else printf("Yes\n");
	}
	return 0;
}
