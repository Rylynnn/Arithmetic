#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
const double SITA=((1.0+sqrt(5.0))/2.0);
int main()
{
	int a,b;
	while (cin>>a>>b)
	{
		if (a>b) swap(a,b);
		if (floor((b-a)*SITA)==a) printf("0\n");
		else printf("1\n");
	}
	return 0;
}
