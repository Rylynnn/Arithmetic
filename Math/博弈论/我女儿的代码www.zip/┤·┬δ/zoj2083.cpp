#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;

int sg[100];
int SG(int x)
{
	if (sg[x]!=-1) return sg[x];
	int vis[110];
	memset(vis,0,sizeof(vis));
	for (int i=x-2;i>=0;i--)
	{
		vis[SG(i)^SG(x-i-2)]=1;
	}
	for (int i=0;;i++)
		if (!vis[i]) return sg[x]=i;
}
int main()
{
	int n;
	memset(sg,-1,sizeof(sg));
	while (scanf("%d",&n)==1)
	{
		int res=0;
		for (int i=1;i<=n;i++)
		{
			int x;
			scanf("%d",&x);
			res^=SG(x);
		}
		if (res) printf("Yes\n");
		else printf("No\n");
	}
	return 0;
}
