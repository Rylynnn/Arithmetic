#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;

int main()
{
	int n;
	while (scanf("%d",&n)==1&&n)
	{
		int res=0;
		for (int i=1;i<=n;i++)
		{
			int x;
			scanf("%d",&x);
			res^=x;
		}
		if (res) printf("Rabbit Win!\n");
		else printf("Grass Win!\n");
	}
	return 0;
}
