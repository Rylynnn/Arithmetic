#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int n;
int main()
{
	while (scanf("%d",&n)==1)
	{
		int flag=0,s=0,j=0;
		for (int i=0;i<n;i++)
		{
			int x;
			scanf("%d",&x);
			s^=x;
			if (x>1) flag=1;
			if (x==0) j++;
		}
		if (flag==0) if ((n-j)%2) printf("No\n");
						    else  printf("Yes\n");
		else if (s==0) printf("No\n");
				else   printf("Yes\n");
	}
	return 0;
}	
