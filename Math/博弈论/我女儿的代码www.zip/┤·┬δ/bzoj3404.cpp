#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int pp[10];
int sg[1100000];
int SG(int x)
{
	if (sg[x]!=-1) return sg[x];
	int x1,x2;
	memset(pp,0,sizeof(pp));
	int y=x;
	while (y>0)
	{
		pp[y%10]=1;
		y/=10;
	}
	for (int i=1;i<=9;i++)
		if (pp[i])
		{
			x1=i;
			break;
		}
	for (int i=9;i>=1;i--)
	{
		if (pp[i])
		{
			x2=i;
			break;
		}
	}
	//cout<<x-x1<<" "<<x-x2<<endl;
	if (!SG(x-x1)||!SG(x-x2)) return sg[x]=1;
	return sg[x]=0;
}

int main()
{
	int T;
	cin>>T;
	memset(sg,-1,sizeof(sg));
	sg[0]=0;
	while (T--)
	{
		int n;
		scanf("%d",&n);
		if (SG(n)) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
