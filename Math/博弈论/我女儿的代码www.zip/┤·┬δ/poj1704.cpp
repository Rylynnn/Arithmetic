#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int a[1011],b[1011],sum,k;
int n;

int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		sum=0;
		cin>>n;
		for (int i=0;i<n;i++)
			scanf("%d",&a[i]);
		sort(a,a+n);
		if (n%2==0)
		{
			k=0;
			for (int i=1;i<n;i+=2)
			{
				b[k++]=a[i]-a[i-1]-1;
			}
		}
		else
		{
			k=1;
			b[0]=a[0]-1;
			for (int i=2;i<n;i+=2)
			{
				b[k++]=a[i]-a[i-1]-1;
			}
		}
		for (int i=0;i<k;i++)
			sum^=b[i];
		if (sum) printf("Georgia will win\n");
		else printf("Bob will win\n");
	}
	return 0;
}
