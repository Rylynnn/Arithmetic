#include<iostream>
#include<cstdlib>
#include<stdio.h>
using namespace std;
const int N=3000000;
long long a[N],b[N];
#define LL long long
int main()
{
    int t,k;
    long long n;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%lld",&k,&n);
        a[0]=b[0]=1;
        int i=0,j=0;
        while(a[i]<n)
        {
            i++;
            a[i]=b[i-1]+1;
            while(a[j+1]*k<a[i])
            j++;
            if(a[j]*k<a[i])  b[i]=b[j]+a[i];
            else b[i]=a[i];
        }
        LL ans;
        if(a[i]==n)
        ans=(LL)n-i-1;
        else
        ans=(LL)n-i;
        cout<<ans<<endl;
    }
}

