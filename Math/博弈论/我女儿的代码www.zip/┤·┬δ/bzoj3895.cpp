#include<stdio.h>
#include<string.h>
#include<iostream>
#include<algorithm>
using namespace std;

int sg[55][55000];
int a[55];
int SG(int a,int b)
{
	if(sg[a][b]!=-1) return sg[a][b];
	if(b==1) return sg[a][b]=SG(a+1,0);
	sg[a][b]=0;
	if(a>=1&&!SG(a-1,b))
		sg[a][b]=1;
	if(a>=1&&b&&!SG(a-1,b+1))
		sg[a][b]=1;
	if(a>=2&&((b&&!SG(a-2,b+3))||(b==0&&!SG(a-2,2))))
		sg[a][b]=1;
	if(b>=2&&!SG(a,b-1))
		sg[a][b]=1;
	return sg[a][b];
}
int cas,n,k,j;
int main()
{
	int T;
	cin>>T;
	memset(sg,-1,sizeof(sg));
	while(T--)
	{
		scanf("%d",&n);
		k=0,j=0;
		for(int i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
			if(a[i]==1) j++;
			else k+=a[i]+1;
		}
		if(k) k--;
		if(SG(j,k)) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}

