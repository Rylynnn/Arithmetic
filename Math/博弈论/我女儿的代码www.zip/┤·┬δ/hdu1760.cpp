#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int map[60][60];
int n,m;
int dfs()
{
	for (int i=1;i<=n-1;i++)
	{
		for (int j=1;j<=m-1;j++)
		{
			if (!map[i][j]&&!map[i+1][j]&&!map[i][j+1]&&!map[i+1][j+1])
			{
				map[i][j]=map[i+1][j]=map[i][j+1]=map[i+1][j+1]=1;
				int t=dfs();
				map[i][j]=map[i+1][j]=map[i][j+1]=map[i+1][j+1]=0;
				if (!t) return 1;
			}
		}
	}
	return 0;
}
int main()
{
	while (scanf("%d %d",&n,&m)==2)
	{
		for (int i=1;i<=n;i++)
		{
			string s;
			cin>>s;
			for (int j=0;j<m;j++)
			{
				map[i][j+1]=s[j]-'0';
			}
		}
		int res=dfs();
		if (res) printf("Yes\n");
		else printf("No\n");
	}
	return 0;
}
