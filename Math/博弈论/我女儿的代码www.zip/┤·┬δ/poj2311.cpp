#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int sg[210][210];
int SG(int x,int y)
{
	if (sg[x][y]!=-1) return sg[x][y];
	int vis[1100];
	memset(vis,0,sizeof(vis));
	for (int i=2;i<=x-i;i++)
		vis[SG(i,y)^SG(x-i,y)]=1;
	for (int i=2;i<=y-i;i++)
		vis[SG(x,i)^SG(x,y-i)]=1;
	for (int i=0;;i++)
		if (!vis[i]) return sg[x][y]=i;
}
int main()
{
	int n,m;
	memset(sg,-1,sizeof(sg));
	while (scanf("%d %d",&n,&m)==2)
	{
		if (SG(n,m)) puts("WIN");
		else puts("LOSE");
	}
	return 0;
}	
