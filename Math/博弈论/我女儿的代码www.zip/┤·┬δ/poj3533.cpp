#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int gg[900][900],a[1001],n,a1,a2,a3,ans;

int f(int x,int y);
int g(int x,int y)
{
	if (gg[x][y]!=-1) return gg[x][y];
	if (!x) return gg[x][y]=1<<y;
	if (!y) return gg[x][y]=1<<x;
	int k=1,ans=1,t,x1=x,y1=y,x2=x,y2=y;
	while (x||y)
	{
		t=1<<k;
		if ((x&1||y&1)&&!((x&1)&&(y&1))) ans*=t;
		k<<=1;
		x>>=1,y>>=1;
	}
	k=1;
	while (x1||y1)
	{
		t=1<<k;
		if ((x1&1)&&(y1&1)) ans=f(ans,t/2*3);
		k<<=1;
		x1>>=1,y1>>=1;
	}
	return (gg[x2][y2]=ans);
}

int f(int x,int y)
{
	if (!x||!y) return 0;
	if (x==1) return y;
	if (y==1) return x;
	int ans=0;
	for (int i=x,k1=0;i;i>>=1,k1++)
		if (i&1) for (int j=y,k2=0;j;j>>=1,k2++)
			if (j&1) ans^=g(k1,k2);
	return ans;
}
int solve(int x)
{
	int flag[1001];
	memset(flag,0,sizeof(flag));
	for (int i=1;i<x;i++)
		flag[a[i]]=1;
	int k=1;
	while (flag[k]) ++k;
	return k;
}
int main()
{
	memset(gg,-1,sizeof(gg));
	for (int i=1;i<1001;i++)
		a[i]=solve(i);
	while (scanf("%d",&n)!=EOF)
	{
		ans=0;
		for (int i=0;i<n;i++)
		{
			scanf("%d %d %d",&a1,&a2,&a3);
			ans^=f(a[a1],f(a[a2],a[a3]));
		}
		if (!ans) printf("Yes\n");
		else printf("No\n");
	}
	return 0;
}	
