#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<map>

using namespace std;
typedef long long LL;

map<LL,int> S;
LL f[1000];
int main()
{
	f[1]=1;
	f[2]=1;
	S[1]=1;
	for (int i=3;f[i-1]>(1<<31);i++)
	{
		f[i]=f[i-1]+f[i-2];
		S[f[i]]=1;
	}
	int n;
	while (1)
	{
		scanf("%d",&n);
		if (!n) break;
		if (S[n]) printf("Second win\n");
		else printf("First win\n");
	}
	return 0;
}
