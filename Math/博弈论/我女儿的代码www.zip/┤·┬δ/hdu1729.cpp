#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>

using namespace std;
int SG(int s,int c)
{
	int q=sqrt((double)s);
	while(q+q*q>=s)
		q--;
	if(c>q) return s-c;
	else return SG(q,c);
}
int main()
{
	int n,cas=0;
	while(scanf("%d",&n)!=EOF&&n)
	{
		int s,c;
		printf("Case %d:\n",++cas);
		int res=0;
		while(n--){
			scanf("%d%d",&s,&c);
			res^=SG(s,c);
		}
		if(res)
			printf("Yes\n");
		else
			printf("No\n");
	}
	return 0;
}	
