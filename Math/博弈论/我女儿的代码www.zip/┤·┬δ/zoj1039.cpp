#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
using namespace std;
int dp[1<<19];
int get_state(int state,int x){
    int ret=state;
    for(int i=x;i<=20;i+=x)
        ret&=~(1<<(i-2));
    for(int i=2;i<=20;i++){
        if((1<<(i-2))&ret){
            for(int j=x;i-j-2>=0;j+=x)
                if(!((1<<(i-j-2))&ret)){
                     ret&=~(1<<(i-2));
                     break;
                }
        }
    }
    return ret;
}
int get_dp(int state){
    if(dp[state]!=-1)
        return dp[state];
    for(int i=2;i<=20;i++){
        if(state&(1<<(i-2))){
            int tmp=get_state(state,i);
            if(!get_dp(tmp))
                return dp[state]=1;
        }
    }
    return dp[state]=0;
}
int main(){
    memset(dp,-1,sizeof(dp));
    dp[0]=0;
    int t,n,a[20],cas=0;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int state=0;
        for(int i=0;i<n;i++){
            scanf("%d",&a[i]);
            state|=1<<(a[i]-2);
        }
        printf("Scenario #%d:\n",++cas);
        if(get_dp(state)==0)
            puts("There is no winning move.\n");
        else{
            printf("The winning moves are:");
            for(int i=0;i<n;i++){
                int tmp=get_state(state,a[i]);
                if(!get_dp(tmp))
                    printf(" %d",a[i]);
            }
            puts(".\n");
        }
    }
    return 0;
}
