#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
typedef long long LL;
int main()
{
	int T;
	cin>>T;
	int cas=0;
	while (T--)
	{
		int n;
		scanf("%d",&n);
		LL a=0,b=0;
		while (n--)
		{
			int x,y;
			scanf("%d %d",&x,&y);
			while (x>1&&y>1) x>>=1,y>>=1;
			if (y==1) a+=(LL)x-1;
			if (x==1) b+=(LL)y-1;
		}
		cas++;
		printf("Case %d: %s\n",cas,a>b?"Alice":"Bob");
	}
	return 0;
}
