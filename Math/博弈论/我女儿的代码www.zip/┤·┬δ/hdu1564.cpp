#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int n;
	while (1)
	{
		scanf("%d",&n);
		if (n==0) break;
		if (n&1) printf("ailyanlu\n");
		else printf("8600\n");
	}
	return 0;
}
