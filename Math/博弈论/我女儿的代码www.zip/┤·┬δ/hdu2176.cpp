#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int a[201000];
int main()
{
	int n;
	while(scanf("%d",&n)!=EOF&&n)
	{
		int res=0;
		for (int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			res^=a[i];
		}
		if(res==0)
		{
			printf("No\n");
			continue;
		} 
		printf("Yes\n");
		int ans=0;
		for (int i=1;i<=n;i++)
			if ((res^a[i])<a[i])
			{
				printf("%d %d\n",a[i],(res^a[i]));
			}
	}
	return 0;
}
