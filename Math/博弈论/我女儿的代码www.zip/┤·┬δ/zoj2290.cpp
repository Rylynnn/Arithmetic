#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<iostream>
#include<map>

using namespace std;

map<int,int> S;
int f[1000];
int num=2;
int solve(int n)
{
	int x;
    for(int i=1;i<=num;i++)
    {
        if(n==f[i]) return f[i];
        else if(n<f[i])
		{
			x=i;
			break;
		}
    }
    return solve(n-f[x-1]);
}
int main()
{
	S.clear();
	f[1]=1;
	f[2]=1;
	S[1]=1;
	for (int i=3;f[i-1]<1e8;i++)
	{
		num++;
		f[i]=f[i-1]+f[i-2];
		S[f[i]]=1;
	}
	int n;
	while (scanf("%d",&n)==1)
	{
		int flag=0;
		int ans;
		for (int i=1;i<=num;i++)
			if (n==f[i]) flag=1;
		if (flag)  printf("lose\n");
		else printf("%d\n",solve(n));
	}
	return 0;
}
