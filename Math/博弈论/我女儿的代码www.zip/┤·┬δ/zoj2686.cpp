#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int n,a[40];
int solve(int m){
    int cnt=0;
    for(int i=m;cnt<n;i=(i+1)%n)
        if(a[i]==0)
            break;
        else
            cnt++;
    if(cnt&1)
        return 1;
    cnt=0;
    for(int i=(m-1+n)%n;cnt<n;i=(i-1+n)%n)
        if(a[i]==0)
            break;
        else
            cnt++;
    if(cnt&1)
        return 1;
    for(int i=-1;i<=1;i+=2){
        int k;
        if(i==1)
            k=m;
        else
            k=(m-1+n)%n;
        for(int j=1;j<=a[k];j++){
            a[k]-=j;
            if(!solve((m+i+n)%n)){
                a[k]+=j;
                return 1;
            }
            a[k]+=j;
        }
    }
    return 0;
}
int main(){
    int T;
    cin>>T;
    while(T--){
        scanf("%d",&n);
        for(int i=0;i<n;i++)
            scanf("%d",&a[i]);
        puts(solve(0)?"YES":"NO");
    }
    return 0;
};
