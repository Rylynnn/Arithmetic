#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int T;
	cin>>T;
	int cas=0;
	while (T--)
	{
		int n,k;
		scanf("%d %d",&n,&k);
		cas++;
		printf("Case %d: ",cas);
		if (k==1&&(n%2==1)) printf("first\n");
		else if (n<=k) printf("first\n");
		else printf("second\n");
	}
	return 0;
}
