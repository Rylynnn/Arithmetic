#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
const int inf=1<<26;
int v[10010],n,a,b;
int dp[10010];

int DP(int m)
{
	if (dp[m]!=-inf) return  dp[m];
	int ans=inf;
	for (int i=m+1;i<n;i++)
	{
		if (v[i]-v[m]>=a&&v[i]-v[m]<=b)
			ans=min(ans,v[m]-DP(i));
	}
	if (ans==inf)
		return dp[m]=v[m];
	return dp[m]=ans;
}
int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		scanf("%d %d %d",&n,&a,&b);
		for (int i=0;i<n;i++)
		{
			dp[i]=-inf;
			scanf("%d",&v[i]);
		}
		sort(v,v+n);
		int ans=-inf;
		for (int i=0;i<n;i++)
			if (v[i]>=a&&v[i]<=b) ans=max(ans,DP(i));
		if (ans==-inf) ans=0;
		printf("%d\n",ans);
	}
	return 0;
}
