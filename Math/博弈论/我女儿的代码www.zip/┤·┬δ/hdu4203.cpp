#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		int n,k;
		scanf("%d %d",&n,&k);
		if (k&1)
		{
			if (n&1) printf("1\n");
			else printf("0\n");
		}
		else
		{
			n=n%(k+1);
			if (n==k)	printf("%d\n",k);
			else if (n&1) printf("1\n");
			else printf("0\n");
		}
	}
	return 0;
}
