#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int T;
	cin>>T;
	int cas=0,n;
	while (T--)
	{
		scanf("%d",&n);
		int ans=0;
		for (int i=1;i<=n;i++)
		{
			int x;
			scanf("%d",&x);
			if (i%6==0||i%6==2||i%6==5)
			    ans^=x;
		}
		printf("Case %d: ",++cas);
		if (ans!=0) printf("Alice\n");
		else printf("Bob\n");
	}
	return 0;
}
