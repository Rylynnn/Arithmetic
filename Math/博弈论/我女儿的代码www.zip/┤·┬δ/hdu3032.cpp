#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		int n;
		cin>>n;
		int res=0;
		for (int i=1;i<=n;i++)
		{
			int x;
			scanf("%d",&x);
			if (x%4==0) res^=x-1;
			else if (x%4==1) res^=x;
			else if (x%4==2) res^=x;
			else if (x%4==3) res^=x+1;
		}
		if (res) printf("Alice\n");
		else printf("Bob\n");
	}
	return 0;
}
