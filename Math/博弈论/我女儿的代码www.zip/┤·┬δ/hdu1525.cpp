#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int a,b;
	while (1)
	{
		cin>>a>>b;
		if (a==0&&b==0) break;
		if (a<b) swap(a,b);
		int key=1;
		while (b)
		{
			if (a%b==0||a>=2*b) break;
			a=a-b;
			swap(a,b);
			key^=1;
		}
		if (key) printf("Stan wins\n");
		else printf("Ollie wins\n");
	}
	return 0;
}
