#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
typedef long long LL;
LL n;
int num;
int main()
{
    while(cin>>n){
        for (num=0;n>1;num++)
        {
			int f=0;
			if (num&1)
			{
				if (n%2) f=1;
				n/=2;
				n+=f;
			}
			else
			{
				if (n%9) f=1;
				n/=9;
				n+=f;
			}
		}
		if (num&1) printf("Stan wins.\n");
		else printf("Ollie wins.\n");
    }
    return 0;
}
