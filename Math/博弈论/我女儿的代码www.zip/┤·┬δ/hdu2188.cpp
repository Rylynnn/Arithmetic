#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		int n,m;
		scanf("%d %d",&n,&m);
		if (n<=m) printf("Grass\n");
		else if (n%(m+1)) printf("Grass\n");
		else printf("Rabbit\n");
	}
	return 0;
}
