#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;

int pp[55000];
int n;
int main()
{
	scanf("%d",&n);
	int x,y,z;
	cin>>x>>y>>z;
	pp[x]=pp[y]=pp[z]=1;
	int cnt=0;
	for (int i=1;i<=n-3;i++)
	{
		cin>>x>>y>>z;
		if (pp[x]+pp[y]+pp[z]==2) cnt++;
	}
	if (cnt==1) printf("TAK\n");
	else if (n&1) printf("NIE\n");
	else printf("TAK\n");
	return 0;
}
