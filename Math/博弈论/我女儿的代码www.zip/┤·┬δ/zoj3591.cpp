#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;
typedef long long LL;
LL N,S,W;
LL a[110000];
map<LL,LL> s;
LL ans;
void init()
{
	LL g = S; 	
	for (int i=0; i<N; i++) { 
    	a[i] = g;
    	if( a[i] == 0 ) { a[i] = g = W; }
    	if( g%2 == 0 ) { g = (g/2); }
    	else           { g = (g/2) ^ W; }
	}
}

int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		cin>>N>>S>>W;
		ans=(N+1)*N/2;
		s.clear();
		init();
		s[a[0]]=1;
		if (a[0]==0) ans--;
		for (int i=1;i<N;i++)
		{
			a[i]^=a[i-1];
			ans-=s[a[i]];
			s[a[i]]++;
			if (a[i]==0) ans--;
		}
		cout<<ans<<endl;
	}
	return 0;
}
