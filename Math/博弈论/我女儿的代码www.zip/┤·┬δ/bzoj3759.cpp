#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<map>

using namespace std;

map<int,int> S;
int a[30];
int n,l;
int flag;
void dfs1(int x,int y,int z)
{
	if (x==l+1)
	{
		S[y]++;
		return ;
	}
	for (int i=0;i<=1;i++)
	{
		dfs1(x+1,y^(i*a[x]),z+i);
	}
}
void dfs2(int x,int y,int z)
{
	if (x==n+1)
	{
		if (z!=0)
		{
			if (S[y]) flag=1;
		}
		else 
		{
			if (S[0]>1) flag=1;
		}
		return ;
	}
	for (int i=0;i<=1;i++)
	{
		dfs2(x+1,y^(i*a[x]),z+i);
	}
}
int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		S.clear();
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		l=n/2;
		dfs1(1,0,0);
		flag=0;
		dfs2(l+1,0,0);
		if (flag) printf("Yes\n");
		else printf("No\n");
	}
	return 0;
}
