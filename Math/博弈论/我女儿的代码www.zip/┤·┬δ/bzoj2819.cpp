#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define M 500100
using namespace std;
struct abcd{
    int to,next;
}table[M<<1];
int head[M],tot;
void add(int x,int y)
{
    table[++tot].to=y;
    table[tot].next=head[x];
    head[x]=tot;
}
int n,m,q,tree[1049000],f[M],pos[M],dpt[M],siz[M],son[M],top[M],fa[M],cnt,queue[M],r,h;
void bfs()
{
    int i,j,x;
    queue[++r]=1;
    while(r!=h)
    {
        x=queue[++h];
        dpt[x]=dpt[fa[x]]+1;
        siz[x]=1;
        for(i=head[x];i;i=table[i].next)
        {
            if(table[i].to==fa[x])
                continue;
            fa[table[i].to]=x;
            queue[++r]=table[i].to;
        }
    }
    for(i=n;i;i--)
    {
        x=queue[i];
        siz[fa[x]]+=siz[x];
        if(siz[x]>siz[son[fa[x]]])
            son[fa[x]]=x;
    }
    for(i=1;i<=n;i++)
    {
        x=queue[i];
        if(son[fa[x]]==x)
            top[x]=top[fa[x]];
        else
        {
            top[x]=x;
            for(j=x;j;j=son[j])
                pos[j]=++cnt;
        }
    }
}
void Build_tree()
{
    for(int i=q-1;i;i--)
        tree[i]=tree[i<<1]^tree[i<<1|1];
}
void change(int x,int y)
{
    for(tree[x+=q]=y,x>>=1;x;x>>=1)
        tree[x]=tree[x<<1]^tree[x<<1|1];
}
int getans(int x,int y)
{
    int re=0;
    for(x+=q-1,y+=q+1;x^y^1;x>>=1,y>>=1)
    {
        if(~x&1)re^=tree[x^1];
        if( y&1)re^=tree[y^1];
    }
    return re;
}
int query(int x,int y)
{
    int re=0,fx=top[x],fy=top[y];
    while(fx!=fy)
    {
        if(dpt[fx]<dpt[fy])
            swap(x,y),swap(fx,fy);
        re^=getans(pos[fx],pos[x]);
        x=fa[fx];fx=top[x];
    }
    if(dpt[x]<dpt[y])
        swap(x,y);
    re^=getans(pos[y],pos[x]);
    return re;
}
int main()
{
     
     
    int i,x,y;
    char p[10];
    cin>>n;
    for(q=1;q<=n+1;q<<=1);
    for(i=1;i<=n;i++)
        scanf("%d",&f[i]);
    for(i=1;i<n;i++)
    {
        scanf("%d%d",&x,&y);
        add(x,y);
        add(y,x);
    }
    bfs();
    for(i=1;i<=n;i++)
        tree[pos[i]+q]=f[i];
    Build_tree();
    cin>>m;
    for(i=1;i<=m;i++)
    {
        scanf("%s%d%d",p,&x,&y);
        if(p[0]=='C')
            change(pos[x],y);
        else
            printf("%s\n",query(x,y)==0?"No":"Yes");
    }
}
