#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>

using namespace std;
int a[11000];
int main()
{
	int n;
	while(1)
	{
		scanf("%d",&n);
		if (n==0) break;
		int res=0;
		for (int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			res^=a[i];
		}
		if(res==0)
		{
			printf("0\n");
			continue;
		} 
		int ans=0;
		for (int i=1;i<=n;i++)
			if ((res^a[i])<a[i]) ans++;
		printf("%d\n",ans);
	}
	return 0;
}
		
		
