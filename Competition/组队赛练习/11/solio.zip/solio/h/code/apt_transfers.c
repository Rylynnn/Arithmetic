// Ana Paula Tomas
// transfers
// adapts Dijkstra's algorithm to compute the pareto front
// *** requires 64 bit architecture ***

#include<stdio.h>
#include<stdlib.h>

//--- adapted from packages for graphs and heapmin ----------------
//#include "transfers_graphs.h"
//#include "transfers_heapMin.h"

//typedef unsigned long VALOR;  
//typedef unsigned long PQ_KEY;
//-----------------------------------------------------------------

#define BITS64
#ifdef BITS64
#define LMAX 1000000000    
#define NMAX 1000
#define DEZNMAXQ (NMAX*NMAX*NMAX)
#define INFINITY  ((unsigned long) LMAX*DEZNMAXQ+NMAX*10+1+1)
#endif
// valores dados no enunciado
// arquitetura 32 bits (overflow...)


#ifndef BITS64
#define LMAX 200
#define NMAX 100
#define DEZNMAXQ (NMAX*NMAX*NMAX)
#define INFINITY ((LMAX*DEZNMAXQ+NMAX*10+1)+1)
#endif


//#define DEBUG
#ifdef DEBUG
void printPareto_target();
#endif

//#define DEBUGALL
#ifdef DEBUGALL
void printPareto();
#endif

//============================= heapmin ================

/*-----------------------------------------------------------------------*\
|  Exemplo de implementacao de fila de prioridade (por heap de m�nimo)    |
|   Ana Paula Tomas (adaptado de vers�o DAA)                              |
|   com opera��o decreaseKey e tamb�m increaseKey                         |
\*-----------------------------------------------------------------------*/


// SWERC 2014
typedef unsigned long PQ_KEY;

#define FORMATPRINTVK "(%d,%lu)\n"

//--------------------

typedef struct qnode {
  int vert;
  PQ_KEY vertkey;
} QNODE;

typedef struct heapMin {
  int sizeMax, size;
  QNODE *a;
  int *pos_a;
} HEAPMIN;

//---------  prot�tipos das fun��es dispon�veis --------------------

HEAPMIN *build_heap_min(PQ_KEY v[], int n);
void insert(int v, PQ_KEY key, HEAPMIN *q);
int extractMin(HEAPMIN *q);   // retorna v 
void decreaseKey(int v, PQ_KEY newkey, HEAPMIN *q);
void increaseKey(int vertv, PQ_KEY newkey, HEAPMIN *q); // SWERC 2014

void write_heap(HEAPMIN *q);
void destroy_heap(HEAPMIN *q);

int heap_size(HEAPMIN *q);  // SWERC 2014
int topHeapMin(HEAPMIN *q);  
int inHeap(int v,HEAPMIN *q);
//----------------- defini��o das fun��es e macros ---------------------


#define POSINVALIDA 0

#define LEFT(i) (2*(i))
#define RIGHT(i) (2*(i)+1)
#define PARENT(i) ((i)/2)

static void heapify(int i,HEAPMIN *q);
static void swap(int i,int j,HEAPMIN *q);
static int compare(int i, int j, HEAPMIN *q);
static int pos_valida(int i,HEAPMIN *q);


int topHeapMin(HEAPMIN *q){ // SWERC 2014
  return q -> a[1].vert;
}

int heap_size(HEAPMIN *q){  // SWERC 2014
  return (q -> size);
}

static int compare(int i, int j, HEAPMIN *q){
  if (q -> a[i].vertkey < q -> a[j].vertkey)
    return -1;
  if (q -> a[i].vertkey == q -> a[j].vertkey)
    return 0;
  return 1;
}


static int pos_valida(int i, HEAPMIN *q) {
  return (i >= 1 && i <= q -> size);
}

int inHeap(int v,HEAPMIN *q) {   // SWERC 
  return q -> pos_a[v] != POSINVALIDA;
}

int extractMin(HEAPMIN *q) {
  int vertv = q -> a[1].vert;
  swap(1,q->size,q);
  q -> pos_a[vertv] = POSINVALIDA;  // assinala vertv como removido
  q -> size--;
  heapify(1,q);
  return vertv;
}

void decreaseKey(int vertv, PQ_KEY newkey, HEAPMIN *q){
  int i = q -> pos_a[vertv];
  q -> a[i].vertkey = newkey;

  while(i > 1 && compare(i,PARENT(i),q) < 0){
    swap(i,PARENT(i),q);
    i = PARENT(i);
  }
}

//-- SWERC 2014------------------------------------
void increaseKey(int vertv, PQ_KEY newkey, HEAPMIN *q){
  int i = q -> pos_a[vertv];
  q -> a[i].vertkey = newkey;

  heapify(i,q);
}
//------------------------------------------------------



static void heapify(int i,HEAPMIN *q) {
  // para heap de minimo
  int l, r, smallest;
  l = LEFT(i);
  if (l > q -> size) l = i;
  r = RIGHT(i);
  if (r > q -> size) r = i;
  
  smallest = i;
  if (compare(l,smallest,q) < 0) 
    smallest = l;
  if (compare(r,smallest,q) < 0) 
    smallest = r;
  
  if (i != smallest) {
    swap(i,smallest,q);
    heapify(smallest,q);
  }
}

static void swap(int i,int j,HEAPMIN *q){
  QNODE aux;
  q -> pos_a[q -> a[i].vert] = j;
  q -> pos_a[q -> a[j].vert] = i;
  aux = q -> a[i];
  q -> a[i] = q -> a[j];
  q -> a[j] = aux;
}



HEAPMIN *build_heap_min(PQ_KEY vec[], int n){
  // supor que vetor vec[.] guarda elementos nas posi��es 1 a n
  // cria heapMin correspondente em tempo O(n)
  HEAPMIN *q = (HEAPMIN *)malloc(sizeof(HEAPMIN));
  int i;
  q -> a = (QNODE *) malloc(sizeof(QNODE)*(n+1));
  q -> pos_a = (int *) malloc(sizeof(int)*(n+1));
  q -> sizeMax = n; // posicao 0 nao vai ser ocupada
  q -> size = n;   
  for (i=1; i<= n; i++) {
    q -> a[i].vert = i;
    q -> a[i].vertkey = vec[i];
    q -> pos_a[i] = i;  // posicao inicial do elemento i na heap
  }

  for (i=n/2; i>=1; i--) 
    heapify(i,q);
  return q;
}


void insert(int vertv, PQ_KEY key, HEAPMIN *q)
{ 
  if (q -> sizeMax == q -> size) {
    fprintf(stderr,"Heap is full\n");
    exit(EXIT_FAILURE);
  }
  q -> size++;
  q -> a[q->size].vert = vertv;
  q -> pos_a[vertv] = q -> size;   // supondo 1 <= vertv <= n
  decreaseKey(vertv,key,q);   // diminui a chave e corrige posicao se necessario
}


// --------- auxiliar para ver conteudo  ---------------------
void write_heap(HEAPMIN *q){
  int i;

  printf("Max size: %d\n", q -> sizeMax);
  printf("Current size: %d\n", q -> size);
  
  printf("(Vert,Key)\n---------\n");
  for(i=1; i <= q -> size; i++)
    printf(FORMATPRINTVK,q->a[i].vert,q->a[i].vertkey);

  printf("-------\n(Vert,PosVert)\n---------\n");

  for(i=1; i <= q -> sizeMax; i++)
    if (pos_valida(q -> pos_a[i],q))
      printf("(%d,%d)\n",i,q->pos_a[i]);
}


void destroy_heap(HEAPMIN *q){
  if (q != NULL) {
    free(q -> a);
    free(q -> pos_a);
    free(q);
  }
}
    

//=======================================================================

//=======================  graphs    =========================================

/*-------------------------------------------------------------------*\
|  Tipo abstracto para implementacao de grafos com pesos (int)        |
|    Vers�o simplificada;  |V| <=  MAXVERTS;                          |
|     Assume-se que os v�rtices s�o numerados de 1 a |V|.             |
|   (Adaptado de graphs.h para SWERC)                                 |
\--------------------------------------------------------------------*/

//--- SWERC 2014 transfers
#define MAXVERTS 1000
typedef unsigned long VALOR;
//-----------------------------------------

typedef struct arco {
  int no_final;
  VALOR valor;
  struct arco *prox;
} ARCO;

typedef struct no {
  int label;
  ARCO *adjs;
} NO;

typedef struct graph {
  NO verts[MAXVERTS+1];  // n�s implicitamente numerados de 1 a nvs
  int nvs, narcos;
} GRAFO;

//--- prot�tipos das fun��es dispon�veis----------------------------
//    ATEN��O AOS TIPOS DE ARGUMENTOS E DE RESULTADO


GRAFO *new_graph(int nverts);
/* cria um grafo com nverts vertices e sem arcos */
void destroy_graph(GRAFO *g);
/* liberta o espa�o reservado na cria��o do grafo */
void insert_new_arc(int i, int j, VALOR valor_ij, GRAFO *g);
/* insere arco (i,j) no grafo, bem como o seu peso; n�o evita repeti��es */
void remove_arc(ARCO *arco, int i, GRAFO *g);
/* retira adjacente arco da lista de adjacentes de i */
ARCO *find_arc(int i, int j, GRAFO *g);
/* retorna um apontador para o arco (i,j) ou NULL se n�o existir */

//--- macros de acesso aos campos da estrutura --------------------------

#define NUM_VERTICES(g) ( (g) -> nvs )
// numero de vertices
#define NUM_ARCOS(g) ( (g) -> narcos )
// numero de arcos
#define LABEL_NO(i,g) ((g)  -> verts[i].label)
// label de no
#define ADJS_NO(i,g) ( (g) -> verts[i].adjs )
// primeiro arco da lista de adjacentes do n� i
#define PROX_ADJ(arco) ((arco) -> prox)
// proximo adjacente 
#define ADJ_VALIDO(arco) (((arco) != NULL))
// se arco � v�lido
#define EXTREMO_FINAL(arco) ((arco) -> no_final)
// qual o extremo final de arco
#define VALOR_ARCO(arco) ((arco) -> valor)
// qual o valor do arco

//======  prot�tipos de fun��es auxiliares (privadas) ======
static ARCO* cria_arco(int, VALOR valor_ij);
static void free_arcs(ARCO *);


//======  Implementa��o (defini��o das fun��es) ========================

// para criar um grafo com nverts vertices e sem ramos
GRAFO *new_graph(int nverts)
{
  if (nverts > MAXVERTS) {
    fprintf(stderr,"Erro: %d > MAXVERTS\n",nverts);
    exit(EXIT_FAILURE);
  }
  GRAFO *g = (GRAFO *) malloc(sizeof(GRAFO));
  if (g == NULL) { 
    fprintf(stderr,"Erro: falta memoria\n");
    exit(EXIT_FAILURE);
  }

  NUM_VERTICES(g) = nverts;  
  NUM_ARCOS(g) = 0;
  while (nverts) {
    ADJS_NO(nverts,g) = NULL;
    nverts--;
  }
  return g;
}


// para destruir um grafo criado
void destroy_graph(GRAFO *g)
{ int i;
  if (g != NULL) {
    for (i=1; i<= NUM_VERTICES(g); i++) 
      free_arcs(ADJS_NO(i,g));
    free(g);
  }
}

// para inserir um novo arco num grafo
void insert_new_arc(int i, int j, VALOR valor_ij, GRAFO *g)
{ /* insere arco (i,j) no grafo g, bem como o seu label  */

  ARCO *arco = cria_arco(j,valor_ij);
  PROX_ADJ(arco) = ADJS_NO(i,g);
  ADJS_NO(i,g) = arco;  // novo adjacente fica � cabe�a da lista
  NUM_ARCOS(g)++;
}

// para remover um arco de um grafo (se existir na lista de adjs[i])
void remove_arc(ARCO *arco, int i, GRAFO *g)
{ 
  if (arco != NULL) {
    ARCO *aux = ADJS_NO(i,g), *prev = NULL;
    while (aux != arco && ADJ_VALIDO(aux)) {
      prev = aux;
      aux = PROX_ADJ(aux);
    }
    if (aux == arco) {
      if (prev == NULL) {
	ADJS_NO(i,g)  = PROX_ADJ(arco);
      } else PROX_ADJ(prev) = PROX_ADJ(arco);
      free(arco);
      NUM_ARCOS(g)--;
    }
  }
}

// retorna um apontador para o arco (i,j) ou NULL se n�o existir 
ARCO *find_arc(int i, int j, GRAFO *g){
  ARCO *adj = ADJS_NO(i,g);

  while(adj != NULL && EXTREMO_FINAL(adj) != j)
    adj = PROX_ADJ(adj);

  return adj;
}
    

// ----  as duas funcoes abaixo sao auxiliares nao publicas ----

// reservar memoria para um novo arco e inicializa-lo
static ARCO *cria_arco(int j, VALOR valor)
{ // cria um novo adjacente
  ARCO *arco = (ARCO *) malloc(sizeof(ARCO));
  if (arco == NULL) {
    fprintf(stderr,"ERROR: cannot create arc\n");
    exit(EXIT_FAILURE);
  }
  EXTREMO_FINAL(arco) = j;
  VALOR_ARCO(arco) = valor;
  PROX_ADJ(arco) = NULL;
  return arco;
}

// libertar uma lista de arcos 
static void free_arcs(ARCO *arco)
{ // liberta lista de adjacentes 
  if (arco == NULL) return;
  free_arcs(PROX_ADJ(arco));
  free(arco);
}


//======================================================================



//==================  TRANSFERS ========================================



typedef struct listatuplos {
  VALOR custo;
  int nramos, tipo;  
  struct listatuplos *nxt;
} FRONT;

  
 // deveriam ser ordenadas BST (balanceadas)?
typedef struct nopareto {
  struct listatuplos *front, *provisorios; 
} NOPARETO;

#define T_CUSTO(f) ((f) -> custo)
#define T_NRAMOS(f) ((f) -> nramos)
#define T_TIPO(f) ((f) -> tipo)
#define NXT(list) ((list) -> nxt)

#define PARETO_FRONT(k) ((NoPareto[k].front))
#define PARETO_PROVS(k) ((NoPareto[k].provisorios))


#define COMPUTE_KEY(a) (((unsigned long) T_CUSTO(a)*NMAX*NMAX+T_NRAMOS(a)*10+T_TIPO(a)))

#define NOTSWERCB 0
#define SWERCB 1
//  NOTSWERCB < SWERCB

NOPARETO NoPareto[NMAX+1];
GRAFO *g;
int source, target, n, m;
PQ_KEY pq_dist[NMAX+1]; 


//-----------------------------------------------
void lerDados();
void pareto_dijkstra();
FRONT *provHead2frontHead(int v);
FRONT *cria_tuplo(VALOR c,int r,int t,FRONT *nxt);
FRONT *filter_provs(int v);   // returns next provisional tuple
void handle_arc(VALOR cw, int rw, int tw, int w,HEAPMIN *heap);
void maxSol_ineqs();
//----------------------------------------------------

FRONT *cria_tuplo(VALOR c,int r,int t,FRONT *nxt){
  FRONT *tn = malloc(sizeof(FRONT));
  if (tn == NULL) {
    fprintf(stderr,"ERROR: cannot allocate memory\n");
    exit(1);  
  }
  T_CUSTO(tn) = c;
  T_NRAMOS(tn) = r;
  T_TIPO(tn) = t;
  NXT(tn) = nxt;
  return tn;
}


FRONT *provHead2frontHead(int v){
  FRONT *h;
  h = PARETO_PROVS(v);
  PARETO_PROVS(v) = NXT(PARETO_PROVS(v));
  NXT(h) = PARETO_FRONT(v);
  PARETO_FRONT(v) = h;
  return h;
}

FRONT *filter_provs(int v) {
  FRONT *h;
  if (v == target) return PARETO_PROVS(target);
  
  // filtrar valores com o target TO BE DONE...
  h = PARETO_PROVS(v);
  return h;
}


HEAPMIN *init_heap()
{
  int i;

  for(i=0;i <= n; i++) 
    pq_dist[i] = INFINITY;

  pq_dist[source]=0;
  return build_heap_min(pq_dist,n);

}

void init_pareto_fronts() {
  int v;
  for(v=1; v<=n; v++) {
    PARETO_FRONT(v) = NULL;
    PARETO_PROVS(v) = cria_tuplo(pq_dist[v],n,LABEL_NO(v,g),NULL);
  }
  T_NRAMOS(PARETO_PROVS(source)) = 0;
}

void pareto_dijkstra(){
  int  v, w, tw, rw;
  ARCO *adj;
  FRONT *pv, *pw, *fv;
  VALOR cw;

  // init heap 
  HEAPMIN *heap = init_heap();
  init_pareto_fronts();

  // 
  while(heap_size(heap)!= 0) {

    v = topHeapMin(heap);  //  do not extract

    fv = provHead2frontHead(v);
    if(T_CUSTO(fv) == INFINITY) return;

    if ((pv = filter_provs(v)) == NULL) 
      extractMin(heap);  // extract v from heap
    else { // keep v in queue with its next provisional tuple
      pq_dist[v] = COMPUTE_KEY(pv);
      increaseKey(v,pq_dist[v],heap);
    }

    // relax adjacents if v is not t
    if (v != target) {
      adj = ADJS_NO(v,g);
      while(adj != NULL) {
	w = EXTREMO_FINAL(adj);
	cw = T_CUSTO(fv)+VALOR_ARCO(adj);
	rw = T_NRAMOS(fv)+1;
	tw  = ((T_TIPO(fv)*LABEL_NO(w,g) == SWERCB)? SWERCB : NOTSWERCB);
	pw = PARETO_PROVS(w);
	if (pw != NULL && T_CUSTO(pw) == INFINITY) {
          T_CUSTO(pw) = cw;
	  T_NRAMOS(pw) = rw;
	  T_TIPO(pw) = tw;
	  pq_dist[w] = COMPUTE_KEY(pw);
	  decreaseKey(w,pq_dist[w],heap);
	} else  handle_arc(cw,rw,tw,w,heap);
	adj = PROX_ADJ(adj);
      }
    }
  }
}

void handle_arc(VALOR cw, int rw, int tw, int w,HEAPMIN *heap)
{
  //  Dijkstra invariant implies:  cw > T_CUSTO(PARETO_FRONT(w))
  if (PARETO_FRONT(w) != NULL && rw >= T_NRAMOS(PARETO_FRONT(w))) return;


  FRONT *prev_pw, *pw, *aux;
  pw = PARETO_PROVS(w);
  prev_pw = NULL;

  while (pw != NULL && T_CUSTO(pw) < cw) {
    if (T_NRAMOS(pw) <= rw) return;
    prev_pw = pw; 
    pw = NXT(pw);
  }

  if (pw != NULL) {
    if (T_CUSTO(pw) == cw) {
      if (T_NRAMOS(pw) < rw) return;
      if (T_NRAMOS(pw) == rw && T_TIPO(pw) <= tw) return;
      // new values...
      T_NRAMOS(pw) = rw;
      T_TIPO(pw) = tw;
      pq_dist[w] = COMPUTE_KEY(pw);
      if (inHeap(w,heap)) decreaseKey(w,pq_dist[w],heap);
      else insert(w,pq_dist[w],heap);
      return;
    } else {
      // T_CUSTO(pw) > cw
      while(pw != NULL && T_NRAMOS(pw) >= rw) {
        aux = NXT(pw); // libertar espa�o
	free(pw);
	pw = aux;
      }
    }
  }

  if (prev_pw != NULL) 
    NXT(prev_pw) = cria_tuplo(cw,rw,tw,pw);
  else {
    PARETO_PROVS(w) = cria_tuplo(cw,rw,tw,pw);
    pw = PARETO_PROVS(w);
    pq_dist[w] = COMPUTE_KEY(pw);
    if (inHeap(w,heap)) decreaseKey(w,pq_dist[w],heap);
    else insert(w,pq_dist[w],heap);
  }
}



// ler dados e construir grafo 
void lerDados() {
  int i, p, ai, bi, aux; 
  VALOR ci;
  
  scanf("%d%d%d%d",&n,&p,&source,&target);
  
  g = new_graph(n);

  for(; p > 0; p--) {
    scanf("%d%d",&ai,&bi);
    scanf("%d",&ci);
    insert_new_arc(ai,bi,ci,g);
    insert_new_arc(bi,ai,ci,g);
  }

  scanf("%d",&m);

  for(i=0;i < m; i++)
    LABEL_NO(i+1,g) = NOTSWERCB;

  for(p=0; p<m; p++) {
    scanf("%d",&aux);
    LABEL_NO(aux,g) = SWERCB;
  }
}


VALOR tax_upperbound(FRONT *pb, FRONT *po) {
  VALOR c = T_CUSTO(po)-T_CUSTO(pb);
  int r = T_NRAMOS(pb)-T_NRAMOS(po);
  if (c%r == 0) return (c/r > 1? c/r-1: 0);
  return  c/r;
}


VALOR tax_lowerbound(FRONT *pb, FRONT *po) {
  VALOR c = T_CUSTO(pb)-T_CUSTO(po);
  int r = T_NRAMOS(po)-T_NRAMOS(pb);
  return c/r+1;
}



void maxSol_ineqs()
{
  FRONT *pw = PARETO_FRONT(target), *pb, *prev, *paux ;
  VALOR  upperbound, maxtax, maxi, aux; 

  pb = pw;
  prev = NULL;


  if (T_CUSTO(pw) == INFINITY) {
    printf("Impossible\n");
    return;
  }

  while (pb != NULL && T_TIPO(pb) == NOTSWERCB) {
    prev = pb;
    pb = NXT(pb);
  }

  if (pb ==  NULL) {
    printf("Impossible\n");
    return;   // no SWERCB solution
  }

  // at least one SWERB solution
  if (prev == NULL) {
    printf("Infinity\n");
    return;
  }

  maxtax = 0;

  //  at least one NOTSWERCB with less edges
  do {
    upperbound = tax_upperbound(pb,prev);
    for (paux = pw; upperbound != 0 && paux != prev; paux = NXT(paux))  {
      aux = tax_upperbound(pb,paux);
      if (aux < upperbound) upperbound = aux;
    }
    maxi = upperbound;
    paux = NXT(pb);
    while (maxi != 0 && paux != NULL) {
      if (T_TIPO(paux) == NOTSWERCB) {
	aux = tax_lowerbound(pb,paux);
	if (maxi < aux) maxi = 0;
      }
      paux = NXT(paux);
    }
    if (maxtax < maxi) maxtax = maxi;
    pb = NXT(pb);
    while (pb != NULL && T_TIPO(pb) == NOTSWERCB) {
      prev = pb;
      pb = NXT(pb);
    }
  } while (pb!= NULL);
  
  if (maxtax == 0) printf("Impossible\n");
  else printf("%lu\n",maxtax);
}



int main() {
  

  // reads input data and builds graph
  lerDados();

  pareto_dijkstra();

#ifdef DEBUGALL
  printPareto();
#endif

#ifdef DEBUG
  printPareto_target();
#endif


  maxSol_ineqs();


  //printf("%lu\n",largeD);

  return 0;
}


#ifdef DEBUGALL
void printPareto()
{ 
  int i;
  FRONT *f;

  for(i=0;i<n;i++) {
    printf("---------- NO: %d  ----------------\n",i+1);
    f = PARETO_FRONT(i+1);
    while(f != NULL) {
      printf("(%lu,%d,%d)\n",T_CUSTO(f),T_NRAMOS(f),T_TIPO(f));
      f = NXT(f);
    }
  }
}
#endif


#ifdef DEBUG
void printPareto_target()
{ 
  int i;
  FRONT *f=PARETO_FRONT(target);
  while(f != NULL) {
    printf("(%lu,%d,%d)\n",T_CUSTO(f),T_NRAMOS(f),T_TIPO(f));
    f = NXT(f);
  }
}
#endif













