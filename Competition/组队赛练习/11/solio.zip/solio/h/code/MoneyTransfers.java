// SWERC 2014, Problem Money Transfers
// Approach: Bellman-Ford to find the cost between X and Y using i edges, for 1 <= i < N. O(E*N + N^2).
// Author: Miguel Oliveira
import java.io.*;
import java.util.Arrays;
import java.util.StringTokenizer;

public class MoneyTransfers {
  private static long INFINITY = 1L << 50;

  public static void main(String[] args) throws IOException {
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    StringTokenizer line = new StringTokenizer(input.readLine());
    int N = Integer.parseInt(line.nextToken());
    int E = Integer.parseInt(line.nextToken());
    int start = Integer.parseInt(line.nextToken()) - 1;
    int end = Integer.parseInt(line.nextToken()) - 1;
    int i;
    int[] edges_a = new int[E];
    int[] edges_b = new int[E];
    int[] edges_cost = new int[E];
    for (i = 0; i < E; i++) {
      line = new StringTokenizer(input.readLine());
      edges_a[i] = Integer.parseInt(line.nextToken()) - 1;
      edges_b[i] = Integer.parseInt(line.nextToken()) - 1;
      edges_cost[i] = Integer.parseInt(line.nextToken());
    }
    int M = Integer.parseInt(input.readLine());
    line = new StringTokenizer(input.readLine());
    boolean[] is_ours = new boolean[N];
    for (i = 0; i < M; i++)
      is_ours[Integer.parseInt(line.nextToken()) - 1] = true;

    long[][][] dist = bellmanFord(N, E, start, end, is_ours, edges_a, edges_b, edges_cost);
    long res = findMaxCost(N, dist[end][1], dist[end][0]);
    if (res == INFINITY)  System.out.println("Infinity");
    else if (res < 0)           System.out.println("Impossible");
    else                        System.out.println(res);
  }

  static long[][][] bellmanFord(int N, int E, int start, int end, boolean[] is_ours, int[] edges_a, int[] edges_b, int[] edges_cost) {
    int i, ne;
    long[][][] dist = new long[N][2][N];
    for (i = 0; i < N; i++) {
      Arrays.fill(dist[i][0], INFINITY);
      Arrays.fill(dist[i][1], INFINITY);
    }
    dist[start][1][0] = 0;
    for (ne = 1; ne < N; ne++) {
      for (i = 0; i < E; i++) {
        if (is_ours[edges_a[i]] && is_ours[edges_b[i]]) {   // Only ours.
          dist[edges_a[i]][1][ne] = Math.min(dist[edges_a[i]][1][ne], dist[edges_b[i]][1][ne-1] + edges_cost[i]);
          dist[edges_b[i]][1][ne] = Math.min(dist[edges_b[i]][1][ne], dist[edges_a[i]][1][ne-1] + edges_cost[i]);
        }
        dist[edges_a[i]][0][ne] = Math.min(dist[edges_a[i]][0][ne], dist[edges_b[i]][0][ne-1] + edges_cost[i]);
        dist[edges_b[i]][0][ne] = Math.min(dist[edges_b[i]][0][ne], dist[edges_a[i]][0][ne-1] + edges_cost[i]);
        if (!is_ours[edges_a[i]])
          dist[edges_a[i]][0][ne] = Math.min(dist[edges_a[i]][0][ne], dist[edges_b[i]][1][ne-1] + edges_cost[i]);
        if (!is_ours[edges_b[i]])
          dist[edges_b[i]][0][ne] = Math.min(dist[edges_b[i]][0][ne], dist[edges_a[i]][1][ne-1] + edges_cost[i]);
      }
    }
    return dist;
  }

  static long findMaxCost(int N, long[] dist_ours, long[] dist_global) {
    int i, j;
    for (i = 1; i < N && dist_ours[i] == INFINITY; i++)
      ;
    if (i == N)
      return -1;
    for (j = 1; j < N && dist_global[j] == INFINITY; j++)
      ;
    if (i < j || (i == j && dist_ours[i] < dist_global[j]))
      return INFINITY;

    long res = -1, k, diff, ne;
    for ( ; i < N; i++) {
      if (dist_ours[i] < INFINITY && dist_global[i] > dist_ours[i]) {
        long max_add = INFINITY;
        for (j = 1; j < i; j++) {
          if (dist_global[j] <= dist_ours[i]) {
            max_add = -1;
            break;
          } else if (dist_global[j] < INFINITY) {
            // dist_ours + k * i < dist_global + k * j
            diff = dist_global[j] - dist_ours[i];
            ne = i - j;
            k = diff / ne;
            if (diff % ne == 0)
              --k;
            max_add = Math.min(max_add, k);
          }
        }
        if (max_add >= 0) {
          for (j = i+1; j < N; j++)
            if (dist_global[j] < dist_ours[i]) {
              // garantir que e' mesmo o mais curto
              diff = dist_ours[i] - dist_global[j];
              ne = j - i;
              k = diff / ne;
              if (diff % ne == 0)
                ++k;
              if (max_add < k) {
                max_add = -1;
                break;
              }
            }
          res = Math.max(res, max_add);
        }
      }
    }
    return res;
  }
}
