//--------------------------------------------------------
//  By Ana Paula Tomas  
//  Great Swerc
//  no heuristics 
//  generate and test
//--------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define DEBUG_PRINTSOLS

#define MAXLENOPERAND 10
#define EMPTYPOS 10
#define UNDEFCHAR '*'
#define UNDEFVAL -1

typedef struct letravalor {
  char letra;
  int valor;
} SOLC;


SOLC Solucao[11] = {
  {UNDEFCHAR,UNDEFVAL}, {UNDEFCHAR,UNDEFVAL}, {UNDEFCHAR,UNDEFVAL},
  {UNDEFCHAR,UNDEFVAL}, {UNDEFCHAR,UNDEFVAL}, {UNDEFCHAR,UNDEFVAL},
  {UNDEFCHAR,UNDEFVAL}, {UNDEFCHAR,UNDEFVAL}, {UNDEFCHAR,UNDEFVAL},
  {UNDEFCHAR,UNDEFVAL}, {UNDEFCHAR,0}};


int DigitoVisitado[10] = {0};  // not assigned
int NLetras;
int Problem[10][MAXLENOPERAND+1];  // 10*(10^M-1) < 10^{M+1}
int Length[10];

//-----------------
int resolve(int letra, int n);
int posicao(char c);
int check_sol(int n);

#ifdef DEBUG_PRINTSOLS
void escreve_sol();
#endif

//-----------------

int posicao(char c) {
  int i;
  
  for(i=0; i< NLetras; i++)
    if (Solucao[i].letra == c) return i;

  Solucao[NLetras++].letra = c;
  return NLetras-1;
}


int main() {
  int j, n, i, numsols = 0, maxlen; 
  char linha[MAXLENOPERAND+2];

  Solucao[EMPTYPOS].valor = 0;
  for (i=0; i< 10; i++)   
    Solucao[i].valor = UNDEFVAL;

  scanf("%d",&n);

  NLetras = 0;
  for (i=0; i<n;i++) {
    scanf("%s",linha);

    Length[i] = (int) strlen(linha);    
    for(j=0; linha[j] != '\0'; j++) 
      Problem[i][Length[i]-1-j] = posicao(linha[j]);
    for(; j < MAXLENOPERAND+1; j++) 
      Problem[i][j] = EMPTYPOS;
  }
  
  maxlen = 0;
  for (i=0; i <n-1; i++)
    if (Length[i] > maxlen) maxlen = Length[i];

  if (Length[n-1] > maxlen+1)   // under  n <= 10
    return 0;

  if (Length[n-1] > maxlen) maxlen = Length[n-1];


  numsols = resolve(0,n); 

  printf("%d\n",numsols);

  return 0;
}

#ifdef DEBUG_PRINTSOLS
void escreve_sol(){
  int i;
  for (i=0; i< NLetras; i++)
    printf("(%c,%d) ",Solucao[i].letra,Solucao[i].valor);
  putchar(10);
}
#endif


int resolve(int nletra,int n) {
  int d, s=0;

  if (nletra == NLetras) 
    return check_sol(n);

  for(d=0; d<10; d++)
    if (DigitoVisitado[d] == 0) {
      Solucao[nletra].valor = d;
      DigitoVisitado[d] = 1;
      s += resolve(nletra+1,n);
      Solucao[nletra].valor = UNDEFVAL;
      DigitoVisitado[d] = 0;
    }
  return s;
}


int check_sol(int n) {
  int i, j, carry, s;

  // leftmost digit is not zero
  for(i=0; i<n; i++) 
    if (Solucao[Problem[i][Length[i]-1]].valor == 0) return 0;

  // check sum
  
  for(j=0, carry=0; j< Length[n-1]; j++) {
    s = carry;
    for(i=0; i< n-1; i++)
      s += Solucao[Problem[i][j]].valor;
    if (s%10 != Solucao[Problem[n-1][j]].valor) return 0;
    carry = s/10;
  }
						  
  if (carry == 0) return 1;
  return 0;
}
  
    

