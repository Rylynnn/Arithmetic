
import java.util.*;

public class GreatSwerc {
    public static String[] row;
    public static StringBuffer[] column;
    public static int cols;
    public static int LETTERS = 26;  // A..Z
    public static int[] solution;


    public static int add_cols(int col, int carry) {
	if (col==cols) {
	    /* check if we found a solution */
	    if (is_solution(carry)) {
		// print_sol();
		return 1;
	    } 
	    else 
		return 0;
	}

	assert col<cols;
	return add_col(0, col, carry);
    }


    public static int add_col(int row, int col, int n) {
	int last = column[col].length()-1;
	if (row == last) {
	    /* check column addition */
	    int digit = n%10;
	    int carry = n/10;
	    char result = column[col].charAt(last);
	    int d = get(result);
	    if (d<0) {
		if(!bind(result, digit))
		    return 0;  /* fail imediately */
		/* add remaining columns */
		int count = add_cols(col+1, carry);
		unbind(result);
		return count;
	    } else {
		if (d!=digit)
		    return 0;
		/* add remaining columns */
		int count = add_cols(col+1, carry);
		return count;
	    }
	}

	int d = get(column[col].charAt(row));
	if (d>=0) {
	    return add_col(row+1, col, n+d);
	}
	else {
	    int count = 0; 
	    for(d=0; d<=9; d++) {
		if(!bind(column[col].charAt(row), d))
		    continue;
		count += add_col(row+1, col, n+d);
		unbind(column[col].charAt(row));
	    }
	    return count;    
	}
    }

    public static boolean is_solution(int carry) {
	/* check final carry value */
	if (carry != 0) 
	    return false;

	/* check leading digit for each row */
	for(int i=0; i<row.length; i++) {
	    int d = get(row[i].charAt(0));
	    if (d==0) // && row[i].length()>1)
		return false;
	}
	return true;
    }

    public static int get(char x) {
	assert x>='A' && x<='Z';
	int i = (int)x - (int)'A';
	return solution[i];
    }


    /* check if a digit has been assigned */
    public static boolean assigned(int k) { 
	for(int j=0; j<LETTERS; j++)
	    if(solution[j] == k) 
		return true;
	return false;		  
    }

    public static boolean bind(char x, int k) {
	assert x>='A' && x<='Z';
	int i = (int)x - (int)'A';
	if(solution[i]==k) 
	    return true;
	if(solution[i] < 0) {
	    if(assigned(k)) 
		return false;
	    solution[i] = k;
	    return true;
	} 
	return false;    
    }

    public static void unbind(char x) {
	assert x>='A' && x<='Z';
	int i = (int)x - (int)'A';
	solution[i] = -1;
    }
    
    public static void initialize() {
	/* calcular o número de colunas */
	cols = 0;
	for (int i=0; i<row.length; i++)
	    cols = Math.max(cols, row[i].length());
	
	/* inicializar as colunas */ 
	column = new StringBuffer[cols];
	for (int j=0; j<cols; j++) {
	    column[j] = new StringBuffer();
	    for (int i=0; i<row.length; i++) {
		int k = row[i].length() - j - 1;
		if(k >=0)
		    column[j].append(row[i].charAt(k));      
	    }
	}

	/* inicializar a solução */
	solution = new int[LETTERS];
	for(int j=0; j<LETTERS; j++)
	    solution[j] = -1;  
    }



    public static void print_sol() {
	for(int i=0; i<LETTERS; i++) {
	    if (solution[i] < 0) continue;
	    System.out.println((char) ((int)'A' + i) + " : " + solution[i]);
	}
    }


    public static void readProblem() {
	Scanner sc = new Scanner(System.in);
	int n = sc.nextInt(); // number of lines 
	sc.nextLine();
	row = new String[n];
	for(int i = 0; i<n ; i++) {
	    row[i] = sc.nextLine();
	    //System.out.println(row[i]);
	}
    }
    
    public static void main(String[] args) {
	/* read input */
	readProblem();
	
	/* initialize auxiliary structures */
	initialize();

	int count = add_cols(0, 0);
	System.out.println(count);
    }
}
