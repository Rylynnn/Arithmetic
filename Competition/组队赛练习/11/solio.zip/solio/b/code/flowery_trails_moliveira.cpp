// SWERC 2014, Problem Flowery Trails
// Approach: Dijkstra to find the shortest path between 0 and P-1 and then select the edges that are
// part of a shortest path using the distance vector. O(E log E) due to using heap without decrease key.
// Author: Miguel Oliveira
#include <cstring>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;
const int MAX = 10000+1;
vector<pair<int, int> > adj[MAX];

inline void Push(priority_queue<pair<int, int> >& heap, int v, int cost, int* distance) {
    if (cost < distance[v]) {
        distance[v] = cost;
        heap.push(make_pair(-cost, v));
    }
}

void Dijkstra(int source, int* distance) {
    priority_queue<pair<int, int> > heap;
    Push(heap, source, 0, distance);
    while (!heap.empty()) {
        const pair<int, int> cur = heap.top();
        heap.pop();
        if (-cur.first != distance[cur.second])  // We are not using decrease key
            continue;                            // and there was a cheaper path.
        for (size_t k = 0; k < adj[cur.second].size(); k++) {
            Push(heap, adj[cur.second][k].first, distance[cur.second] + adj[cur.second][k].second, distance);
        }
    }
}

int main() {
    int p, t, a, b, cost, from_source[MAX], from_target[MAX];
    cin >> p >> t;
    while (t--) {
        cin >> a >> b >> cost;
        adj[a].push_back(make_pair(b, cost));
        adj[b].push_back(make_pair(a, cost));
    }
    memset(from_source, 0x3f, sizeof from_source);
    Dijkstra(0, from_source);
    memset(from_target, 0x3f, sizeof from_target);
    Dijkstra(p-1, from_target);
    int res = 0;
    for (int i = 0; i < p; i++)
        for (size_t j = 0; j < adj[i].size(); j++) {
            int cost_up = from_source[i] + adj[i][j].second + from_target[adj[i][j].first];
            int cost_down = from_target[i] + adj[i][j].second + from_source[adj[i][j].first];
            if (min(cost_up, cost_down) == from_source[p-1]) {
                res += adj[i][j].second;
            }
        }
    cout << res << endl;
    return 0;
}
