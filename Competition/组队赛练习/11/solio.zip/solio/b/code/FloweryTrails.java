import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Map;
import java.util.HashMap;
import java.util.Queue;
import java.util.PriorityQueue;
import java.util.LinkedList;

/**
 * @author Margarida Mamede
 */

  
public class FloweryTrails
{

    public static final int PLUS_INFINITY = Integer.MAX_VALUE;

    public static final int ENTRANCE = 0;


    private int numNodes;

    private Map<Edge,Edge> edgesMap;

    private Queue<Edge>[] edges;

    //
    // Shortest Paths
    //

    private int[] cost;

    private Queue<Edge>[] via;

    private boolean[] selected;

    private Queue<Entry> connected;


    public FloweryTrails( int numPoints, int numEdges )
    {
        numNodes = numPoints;
        int capacity = numNodes * (numNodes - 1) / 2;
        if ( numEdges < capacity )
            capacity = numEdges;
        edgesMap = new HashMap<Edge,Edge>(capacity);
    }


    public void addTrail( int node1, int node2, int weight )
    {
        if ( node1 != node2 )
        {
            Edge newEdge = new Edge(node1, node2, weight);
            Edge oldEdge = edgesMap.get(newEdge);
            if ( oldEdge == null )
                edgesMap.put(newEdge, newEdge);
            else
                oldEdge.update(weight);
        }
    }


    public int possibleTrailsLength( )
    {
        this.buildAdjacencyLists();
        this.dijkstra(ENTRANCE, numNodes - 1);
        return this.breadthFirst(numNodes - 1);
    }
        

    @SuppressWarnings("unchecked")
    private void buildAdjacencyLists( )
    {
        edges = ( Queue<Edge>[] ) new Queue[numNodes];
        for ( int i = 0; i < numNodes; i++ )
            edges[i] = new LinkedList<Edge>();

        for ( Edge edge : edgesMap.keySet() )
        {
            edges[ edge.getNode1() ].add(edge);
            edges[ edge.getNode2() ].add(edge);
        }
        edgesMap = null;
    }


    @SuppressWarnings("unchecked")
    private void dijkstra( int root, int target )
    {
        cost = new int[numNodes];
        via = ( Queue<Edge>[] ) new Queue[numNodes];
        selected = new boolean[numNodes];
        connected = new PriorityQueue<Entry>(numNodes);

        for ( int i = 0; i < numNodes; i++ )
            cost[i] = PLUS_INFINITY;
        cost[root] = 0;
        connected.add( new Entry(0, root) );

        do 
            {
                int node = connected.remove().getValue();
                if ( node == target )
                    break;
                if ( !selected[node] )
                {
                    selected[node] = true;
                    this.exploreNode(node);
                }
            }
        while ( !connected.isEmpty() );

        cost = null;
        selected = null;
        connected = null;
    }


    private void exploreNode( int head )
    {
        for ( Edge edge : edges[head] )
        {
            int tail = edge.getOpposite(head);
            if ( !selected[tail] )
            {
                int newCost = cost[head] + edge.getWeight();
                if ( newCost < cost[tail] )
                {
                    cost[tail] = newCost; 
                    via[tail] = new LinkedList<Edge>(); 
                    via[tail].add(edge);
                    connected.add( new Entry(newCost, tail) ); 
                }
                else if ( newCost == cost[tail] )
                    via[tail].add(edge);
            }
        }
    }


    //
    // Pre-condition: cost[ENTRANCE][target] < PLUS_INFINITY
    //
    private int breadthFirst( int target )
    {
        Queue<Integer> waiting = new LinkedList<Integer>();
        boolean[] found = new boolean[numNodes];

        waiting.add(target);
        found[target] = true;
        found[ENTRANCE] = true;
        int sum = 0;

        do  
            {
                int tail = waiting.remove();
                for ( Edge edge : via[tail] )
                {
                    int head = edge.getOpposite(tail);
                    sum += edge.getWeight() * edge.getQuantity();
                    if ( !found[head] )
                    {
                        waiting.add(head);
                        found[head] = true;
                    }
                }
            }
        while ( !waiting.isEmpty() );

        return sum;
    }
        

    public static void main( String[] args ) throws IOException
    {
        BufferedReader input = 
            new BufferedReader( new InputStreamReader(System.in) );

        StringTokenizer line = new StringTokenizer( input.readLine() );
        int numPoints = Integer.parseInt( line.nextToken() );
        int numTrails = Integer.parseInt( line.nextToken() );
        FloweryTrails park = new FloweryTrails(numPoints, numTrails);
            
        for ( int i = 0; i < numTrails; i++ )
        {
            line = new StringTokenizer( input.readLine() );
            int p1 = Integer.parseInt( line.nextToken() );
            int p2 = Integer.parseInt( line.nextToken() );
            int length = Integer.parseInt( line.nextToken() );
            park.addTrail(p1, p2, length);
        }

        input.close();
        System.out.println( 2 * park.possibleTrailsLength() );
    }


}


////////////////////////////////////////////////////////////////////////////
//
// CLASS Edge
//
////////////////////////////////////////////////////////////////////////////

class Edge
{

    public static final int MAX_VALUE = 10000;


    private int node1;

    private int node2;

    private int weight;

    private int quantity;


    public Edge( int theNode1, int theNode2, int theWeight )
    {  
        if ( theNode1 < theNode2 )
        {
            node1 = theNode1;
            node2 = theNode2;
        }
        else
        {
            node1 = theNode2;
            node2 = theNode1;
        }
        weight = theWeight;
        quantity = 1;
    }


    public void update( int newWeight )
    {
        if ( newWeight < weight )
        {  
            weight = newWeight;
            quantity = 1;
        }
        else if ( newWeight == weight )
            quantity++;
    }


    public int getNode1( )
    {
        return node1;
    }


    public int getNode2( )
    {
        return node2;
    }


    public int getOpposite( int node )
    {
        if ( node == node1 )
            return node2;
        return node1;
    }


    public int getWeight( )
    {
        return weight;
    }


    public int getQuantity( )
    {
        return quantity;
    }


    public int hashCode( )
    {
        return node1 * MAX_VALUE + node2;
    }


    public boolean equals( Object object )
    {
        Edge edge = ( Edge ) object;
        return node1 == edge.node1 && node2 == edge.node2;
    }


}


////////////////////////////////////////////////////////////////////////////
//
// CLASS Entry
//
////////////////////////////////////////////////////////////////////////////

class Entry implements Comparable<Entry>
{

    private int key;

    private int value;


    public Entry( int theKey, int theValue )
    {
        key = theKey;
        value = theValue;
    }


    public int getKey( )
    {
        return key;
    }


    public int getValue( )
    {
        return value;
    }


    public int compareTo( Entry entry )
    {
        int keyDiff = key - entry.key;
        if ( keyDiff != 0 )
            return keyDiff;

        return value - entry.value;
    }


}
