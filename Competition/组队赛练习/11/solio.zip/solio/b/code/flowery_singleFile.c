// Ana Paula Tomas
// flowery paths

#include<stdio.h>
#include<stdlib.h>

/*
//--- adaptedfrom already implemented package for graphs and heapmin --
#include "flowery_graphs.h"
#include "heapMin.h"
//-----------------------------------------------------------------
*/

//======================= graphs =================================
// with a simple implementation of adjacent lists (not hash tables)
//================================================================

#define MAXVERTS 10000

// types of values in arcs
//#define LONGVALUE

#ifdef LONGVALUE
typedef unsigned long VALUE;
#define FORMATPRINT "%lu\n"
#define READVALUE "%lu"
#define PRINTVALUE "%lu"
#endif

#ifndef LONGVALUE
typedef int VALUE;
#define FORMATPRINT "%d\n"
#define READVALUE "%d"
#define PRINTVALUE "%d"
#endif



typedef struct arco {
  int no_final;
  VALUE valor;
  int multiplicidade;   // novo campo // NEW-- 2014
  struct arco *prox;
} ARCO;

typedef struct no {
  //int label;
  ARCO *adjs;
} NO;

typedef struct graph {
  NO verts[MAXVERTS+1];  // n�s implicitamente numerados de 1 a nvs
  int nvs, narcos;
} GRAFO;

//--- prot�tipos das fun��es dispon�veis----------------------------
//    ATEN��O AOS TIPOS DE ARGUMENTOS E DE RESULTADO


GRAFO *new_graph(int nverts);
/* cria um grafo com nverts vertices e sem arcos */
void destroy_graph(GRAFO *g);
/* liberta o espa�o reservado na cria��o do grafo */
void insert_new_arc(int i, int j, VALUE valor_ij, GRAFO *g);
// NEW-- 2014
/* insere arco (i,j) no grafo, bem como o seu peso; regista repeti��es */
void remove_arc(ARCO *arco, int i, GRAFO *g);
/* retira adjacente arco da lista de adjacentes de i */
ARCO *find_arc(int i, int j, GRAFO *g);
/* retorna um apontador para o arco (i,j) ou NULL se n�o existir */

//--- macros de acesso aos campos da estrutura --------------------------

#define NUM_VERTICES(g) ( (g) -> nvs )
// numero de vertices
#define NUM_ARCOS(g) ( (g) -> narcos )
// numero de arcos
#define ADJS_NO(i,g) ( (g) -> verts[i].adjs )
// primeiro arco da lista de adjacentes do n� i
#define PROX_ADJ(arco) ((arco) -> prox)
// proximo adjacente 
#define ADJ_VALIDO(arco) (((arco) != NULL))
// se arco � v�lido
#define EXTREMO_FINAL(arco) ((arco) -> no_final)
// qual o extremo final de arco
#define VALOR_ARCO(arco) ((arco) -> valor)
// qual o valor do arco
#define MULT_ARCO(arco) ((arco) -> multiplicidade)
// qual o valor do arco   // NEW-- 2014


//======  prot�tipos de fun��es auxiliares (privadas) ======
static ARCO* cria_arco(int j, VALUE valor_ij);
static void free_arcs(ARCO *);


//======  Implementa��o (defini��o das fun��es) ========================

// para criar um grafo com nverts vertices e sem ramos
GRAFO *new_graph(int nverts)
{
  if (nverts > MAXVERTS) {
    fprintf(stderr,"Erro: %d > MAXVERTS\n",nverts);
    exit(EXIT_FAILURE);
  }
  GRAFO *g = (GRAFO *) malloc(sizeof(GRAFO));
  if (g == NULL) { 
    fprintf(stderr,"Erro: falta memoria\n");
    exit(EXIT_FAILURE);
  }

  NUM_VERTICES(g) = nverts;  
  NUM_ARCOS(g) = 0;
  while (nverts) {
    ADJS_NO(nverts,g) = NULL;
    nverts--;
  }
  return g;
}


// para destruir um grafo criado
void destroy_graph(GRAFO *g)
{ int i;
  if (g != NULL) {
    for (i=1; i<= NUM_VERTICES(g); i++) 
      free_arcs(ADJS_NO(i,g));
    free(g);
  }
}

// para inserir um arco no grafo se interessar
void insert_new_arc(int i, int j, VALUE valor_ij, GRAFO *g)
{ /* insere arco (i,j) no grafo g, bem como o seu label  */
  // se nao existir;  
  // se existir aumenta multiplicidade, a menos que seja pior

  /// changed 
  ARCO *arco = find_arc(i,j,g);
  
  if (arco == NULL) {
    arco = cria_arco(j,valor_ij);
    PROX_ADJ(arco) = ADJS_NO(i,g);
    ADJS_NO(i,g) = arco;  // novo adjacente fica � cabe�a da lista
    NUM_ARCOS(g)++;
  } else {
    if (VALOR_ARCO(arco) > valor_ij) {
      VALOR_ARCO(arco) = valor_ij;
      MULT_ARCO(arco) = 1;
    } else if (VALOR_ARCO(arco) == valor_ij) 
      MULT_ARCO(arco)++;
  }
}


// para remover um arco de um grafo (se existir na lista de adjs[i])
void remove_arc(ARCO *arco, int i, GRAFO *g)
{ 
  if (arco != NULL) {
    ARCO *aux = ADJS_NO(i,g), *prev = NULL;
    while (aux != arco && ADJ_VALIDO(aux)) {
      prev = aux;
      aux = PROX_ADJ(aux);
    }
    if (aux == arco) {
      if (prev == NULL) {
	ADJS_NO(i,g)  = PROX_ADJ(arco);
      } else PROX_ADJ(prev) = PROX_ADJ(arco);
      free(arco);
      NUM_ARCOS(g)--;
    }
  }
}

// retorna um apontador para o arco (i,j) ou NULL se n�o existir 
ARCO *find_arc(int i, int j, GRAFO *g){
  ARCO *adj = ADJS_NO(i,g);

  while(adj != NULL && EXTREMO_FINAL(adj) != j)
    adj = PROX_ADJ(adj);
    
  return adj;
}
    

// ----  as duas funcoes abaixo sao auxiliares nao publicas ----

// reservar memoria para um novo arco e inicializa-lo
static ARCO *cria_arco(int j, VALUE valor)
{ // cria um novo adjacente
  ARCO *arco = (ARCO *) malloc(sizeof(ARCO));
  if (arco == NULL) {
    fprintf(stderr,"ERROR: cannot create arc\n");
    exit(EXIT_FAILURE);
  }
  EXTREMO_FINAL(arco) = j;
  VALOR_ARCO(arco) = valor;
  PROX_ADJ(arco) = NULL;
  MULT_ARCO(arco) = 1;  // NEW -- 2014
  return arco;
}

// libertar uma lista de arcos 
static void free_arcs(ARCO *arco)
{ // liberta lista de adjacentes 
  if (arco == NULL) return;
  free_arcs(PROX_ADJ(arco));
  free(arco);
}




//=========================  heapmin ==============================

typedef struct qnode {
  int vert;
  VALUE vertkey;
} QNODE;

typedef struct heapMin {
  int sizeMax, size;
  QNODE *a;
  int *pos_a;
} HEAPMIN;

//---------  prot�tipos das fun��es dispon�veis --------------------

HEAPMIN *build_heap_min(VALUE v[], int n);
void insert(int v, VALUE key, HEAPMIN *q);
int extractMin(HEAPMIN *q);   // retorna v 
void decreaseKey(int v, VALUE newkey, HEAPMIN *q);

void write_heap(HEAPMIN *q);
void destroy_heap(HEAPMIN *q);


//----------------- defini��o das fun��es e macros ---------------------

#define POSINVALIDA 0

#define LEFT(i) (2*(i))
#define RIGHT(i) (2*(i)+1)
#define PARENT(i) ((i)/2)

static void heapify(int i,HEAPMIN *q);
static void swap(int i,int j,HEAPMIN *q);
static int compare(int i, int j, HEAPMIN *q);
static int pos_valida(int i,HEAPMIN *q);

static int compare(int i, int j, HEAPMIN *q){
  if (q -> a[i].vertkey < q -> a[j].vertkey)
    return -1;
  if (q -> a[i].vertkey == q -> a[j].vertkey)
    return 0;
  return 1;
}


static int pos_valida(int i, HEAPMIN *q) {
  return (i >= 1 && i <= q -> size);
}

int extractMin(HEAPMIN *q) {
  int vertv = q -> a[1].vert;
  swap(1,q->size,q);
  q -> pos_a[vertv] = POSINVALIDA;  // assinala vertv como removido
  q -> size--;
  heapify(1,q);
  return vertv;
}

void decreaseKey(int vertv, VALUE newkey, HEAPMIN *q){
  int i = q -> pos_a[vertv];
  q -> a[i].vertkey = newkey;

  while(i > 1 && compare(i,PARENT(i),q) < 0){
    swap(i,PARENT(i),q);
    i = PARENT(i);
  }
}


static void heapify(int i,HEAPMIN *q) {
  // para heap de minimo
  int l, r, smallest;
  l = LEFT(i);
  if (l > q -> size) l = i;
  r = RIGHT(i);
  if (r > q -> size) r = i;
  
  smallest = i;
  if (compare(l,smallest,q) < 0) 
    smallest = l;
  if (compare(r,smallest,q) < 0) 
    smallest = r;
  
  if (i != smallest) {
    swap(i,smallest,q);
    heapify(smallest,q);
  }
}

static void swap(int i,int j,HEAPMIN *q){
  QNODE aux;
  q -> pos_a[q -> a[i].vert] = j;
  q -> pos_a[q -> a[j].vert] = i;
  aux = q -> a[i];
  q -> a[i] = q -> a[j];
  q -> a[j] = aux;
}



HEAPMIN *build_heap_min(VALUE vec[], int n){
  // supor que vetor vec[.] guarda elementos nas posi��es 1 a n
  // cria heapMin correspondente em tempo O(n)
  HEAPMIN *q = (HEAPMIN *)malloc(sizeof(HEAPMIN));
  int i;
  q -> a = (QNODE *) malloc(sizeof(QNODE)*(n+1));
  q -> pos_a = (int *) malloc(sizeof(int)*(n+1));
  q -> sizeMax = n; // posicao 0 nao vai ser ocupada
  q -> size = n;   
  for (i=1; i<= n; i++) {
    q -> a[i].vert = i;
    q -> a[i].vertkey = vec[i];
    q -> pos_a[i] = i;  // posicao inicial do elemento i na heap
  }

  for (i=n/2; i>=1; i--) 
    heapify(i,q);
  return q;
}


void insert(int vertv, VALUE key, HEAPMIN *q)
{ 
  if (q -> sizeMax == q -> size) {
    fprintf(stderr,"Heap is full\n");
    exit(EXIT_FAILURE);
  }
  q -> size++;
  q -> a[q->size].vert = vertv;
  q -> pos_a[vertv] = q -> size;   // supondo 1 <= vertv <= n
  decreaseKey(vertv,key,q);   // diminui a chave e corrige posicao se necessario
}


// --------- auxiliar para ver conteudo  ---------------------
void write_heap(HEAPMIN *q){
  int i;

  printf("Max size: %d\n", q -> sizeMax);
  printf("Current size: %d\n", q -> size);
  
  printf("(Vert,Key)\n---------\n");
  for(i=1; i <= q -> size; i++){
    printf("(%d,", q->a[i].vert);
    printf(PRINTVALUE, q->a[i].vertkey);
    printf("\n");
  }

  printf("-------\n(Vert,PosVert)\n---------\n");

  for(i=1; i <= q -> sizeMax; i++)
    if (pos_valida(q -> pos_a[i],q))
      printf("(%d,%d)\n",i,q->pos_a[i]);
}


void destroy_heap(HEAPMIN *q){
  if (q != NULL) {
    free(q -> a);
    free(q -> pos_a);
    free(q);
  }
}
    
//=========================================================





//=================================================================
//    FLOWERY TRAILS
//=================================================================

#define LMAX 1000    
// valor dado no enunciado


typedef struct list {
  int node;
  ARCO *arco;
  struct list *nxt;
} LISTNODE;


VALUE adapt_dijkstra(int source,int target,GRAFO *g);
VALUE flowers(int target,int source,LISTNODE *precs[],GRAFO *g);

int main() {

  int p, t, i, j, ne;
  VALUE fij;
  GRAFO *g;  
  
  // p number of nodes  t edges 
  scanf("%d%d",&p,&t);
  
  g = new_graph(p);
  
  for(ne = 0; ne < t; ne++) {
    scanf("%d%d",&i,&j);
    scanf(READVALUE,&fij);
    if (i != j) {
      insert_new_arc(i+1,j+1,fij,g);
      insert_new_arc(j+1,i+1,fij,g); // can be improved
    }
  }

  printf(FORMATPRINT,adapt_dijkstra(1,p,g));

  return 0;
}

// shortest path (nodes that precede w)
void remove_precs(LISTNODE *prec);


LISTNODE *cria_prec_node(int v,ARCO *arcovw, LISTNODE *next) {
  LISTNODE *prec = malloc(sizeof(LISTNODE));
  if (prec == NULL) exit(1);
  prec -> node = v;
  prec -> arco = arcovw;
  prec -> nxt = next;
  return prec;
}

void remove_precs(LISTNODE *prec) {
  LISTNODE *aux;
  while (prec != NULL) {
    aux = prec -> nxt;
    free(prec);
    prec = aux;
  }
}  

VALUE adapt_dijkstra(int source,int target,GRAFO *g) {
  VALUE dist[target+1];
  int i, v, w;
  VALUE infty = LMAX*(1+NUM_ARCOS(g)/2);
  HEAPMIN *heap;
  ARCO *adj;

  LISTNODE **precs = malloc((target+1)*sizeof(LISTNODE *));

  // init heap 
  for(i=0;i <= target; i++) {
    dist[i] = infty;
    precs[i] = NULL;
  }
  dist[source]=0;
  heap = build_heap_min(dist, target);

  // 
  while((v = extractMin(heap))!= target) {
    adj = ADJS_NO(v,g);
    while(adj != NULL) {
      w = EXTREMO_FINAL(adj);
      if (dist[w] > dist[v]+VALOR_ARCO(adj)) {
	dist[w] = dist[v]+VALOR_ARCO(adj);
	if (precs[w] != NULL) remove_precs(precs[w]);
        precs[w] = cria_prec_node(v,adj,NULL);
        decreaseKey(w,dist[w],heap);
      } else if (dist[w] == dist[v]+VALOR_ARCO(adj)) 
        precs[w] = cria_prec_node(v,adj,precs[w]); 
      adj = PROX_ADJ(adj);
    }
  }
 
  return 2*flowers(target,source,precs,g);
}



VALUE dfs_visit(int v,int source,int visited[],LISTNODE *precs[],GRAFO *g)
{
  VALUE total;
  int w;
  LISTNODE *precsv;
  ARCO *arco;

  visited[v] = 1;
  
  if (v == source) return 0;
  total = 0;
  precsv = precs[v];

  while (precsv != NULL)  {
    w = precsv -> node;
    arco = precsv -> arco; // find_arc(w,v,g);
    total += (VALOR_ARCO(arco)*MULT_ARCO(arco));
    if (!visited[w])  
      total += dfs_visit(w,source,visited,precs,g);
    precsv = precsv -> nxt;
  }

  return total;
}


VALUE flowers(int target,int source,LISTNODE *precs[], GRAFO *g) {
  int i,visited[target+1];
  for(i=1; i <target+1; i++) visited[i] = 0;

  return dfs_visit(target,source,visited,precs,g);
}

