// SWERC 2014, Problem: Safe Secret
// Approach: Dynamic Programming. O(n^3).
// Author: Miguel Oliveira
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int MAX = 2 * 200 + 2;

long long dp_max[MAX][MAX], dp_min[MAX][MAX];
int n, numbers[MAX];
char done[MAX][MAX], op[MAX];

void Go(int i, int j) {
  if (!done[i][j]) {
    done[i][j] = 1;
    if (i == j)
      dp_max[i][i] = dp_min[i][i] = numbers[i];
    else {
      dp_max[i][j] = LLONG_MIN, dp_min[i][j] = LLONG_MAX;
      for (int k = i; k < j; k++) {
        Go(i, k);
        Go(k+1, j);
        if (op[k] == '+' || op[k] == '?') {           // Addition
          dp_max[i][j] = max(dp_max[i][j], dp_max[i][k] + dp_max[k+1][j]);
          dp_min[i][j] = min(dp_min[i][j], dp_min[i][k] + dp_min[k+1][j]);
        }
        if (op[k] == '-' || op[k] == '?') {           // Subtraction
          dp_max[i][j] = max(dp_max[i][j], dp_max[i][k] - dp_min[k+1][j]);
          dp_min[i][j] = min(dp_min[i][j], dp_min[i][k] - dp_max[k+1][j]);
        }
        if (op[k] == '*' || op[k] == '?') {           // Multiplication
          // (max1 * max2) or (min1 * min2) or (max1 * min2) or (min1 * max2)
          dp_max[i][j] = max(dp_max[i][j], max(dp_max[i][k] * dp_max[k+1][j], dp_min[i][k] * dp_min[k+1][j]));
          dp_max[i][j] = max(dp_max[i][j], max(dp_max[i][k] * dp_min[k+1][j], dp_min[i][k] * dp_max[k+1][j]));
          dp_min[i][j] = min(dp_min[i][j], min(dp_min[i][k] * dp_min[k+1][j], dp_max[i][k] * dp_min[k+1][j]));
          dp_min[i][j] = min(dp_min[i][j], min(dp_min[i][k] * dp_max[k+1][j], dp_max[i][k] * dp_max[k+1][j]));
        }
      }
    }
  }
}

int main() {
  int i;
  scanf("%d", &n);
  for (i = 0; i < n; i++) {
    scanf("%d %c", &numbers[i], &op[i]);
    numbers[i+n] = numbers[i], op[i+n] = op[i];
  }
  for (i = 0; i < n; i++) {
    Go(i, n + i - 1);
    printf("%lld%lld", abs(dp_min[i][n+i-1]), abs(dp_max[i][n+i-1]));
  }
  puts("");
  return 0;
}
