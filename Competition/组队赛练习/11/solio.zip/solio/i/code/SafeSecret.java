import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.StringTokenizer;

/**
 * @author Margarida Mamede
 */


public class SafeSecret
{

    private int seqLength;

    private char[] operators;

    private long[][][] optValues;


    public SafeSecret( int sequenceLength )
    {
        seqLength = sequenceLength;
        operators = new char[seqLength];
        optValues = new long[seqLength][seqLength][2];
    }


    public void addPair( int pos, int number, char symbol )
    {
        operators[(pos + 1) % seqLength] = symbol;

        // Line 0: size 1 (expressions with 1 number).
        optValues[0][pos][0] = number;
        optValues[0][pos][1] = number;
    }


    public long[][] computeMinMax( )
    {
        this.computeOptValues();
        return optValues[seqLength - 1];
    }


    private void computeOptValues( )
    {
        int left, right, line, sizeLeft;
        long[] res = new long[2];
        
        // Line 1: size 2 (expressions with 2 numbers).
        for ( left = 0; left < seqLength; left++ )
        {  
            right = (left + 1) % seqLength;
            this.evaluate(0, left, 0, right, optValues[1][left]);
        }

        // Lines 2 ... seqLength - 1.
        for ( line = 2; line < seqLength; line++ )
            for ( left = 0; left < seqLength; left++ )
            { 
                // lineLeft = 0; sizeLeft = 1.
                right = (left + 1) % seqLength;
                this.evaluate(0, left, line-1, right, optValues[line][left]);

                for ( sizeLeft = 2; sizeLeft <= line; sizeLeft++ )
                { 
                    right = (left + sizeLeft) % seqLength;
                    this.evaluate(sizeLeft-1, left, line-sizeLeft, right, res);

                    if ( res[0] < optValues[line][left][0] )
                        optValues[line][left][0] = res[0];

                    if ( res[1] > optValues[line][left][1] )
                        optValues[line][left][1] = res[1];
                }
            }
    }
        

    private void evaluate( int l1, int c1, int l2, int c2, long[] res )
    { 
        long min1 = optValues[l1][c1][0];
        long max1 = optValues[l1][c1][1];
        long min2 = optValues[l2][c2][0];
        long max2 = optValues[l2][c2][1];

        switch ( operators[c2] ) 
        {
            case '+': this.evalS(min1, max1, min2, max2, res);
                      break;

            case '-': this.evalD(min1, max1, min2, max2, res);
                      break;

            case '*': this.evalP(min1, max1, min2, max2, res);
                      break;

            case '?': this.evalX(min1, max1, min2, max2, res);
                      break;

            default:  System.out.println("ERROR in operator");
                      break;
        }
    }


    private void evalS( long min1, long max1, long min2, long max2, long[] res )
    { 
        // Sum: min
        res[0] = min1 + min2;

        // Sum: max
        res[1] = max1 + max2;
    }
        

    private void evalD( long min1, long max1, long min2, long max2, long[] res )
    { 
        // Diff: min
        res[0] = min1 - max2;

        // Diff: max
        res[1] = max1 - min2;
    }
        

    private void evalP( long min1, long max1, long min2, long max2, long[] res )
    { 
        // Prod: min and max
        long value = min1 * min2;
        res[0] = value;
        res[1] = value;

        value = min1 * max2;
        if ( value < res[0] )
            res[0] = value;
        else if ( value > res[1] )
            res[1] = value;

        value = max1 * min2;
        if ( value < res[0] )
            res[0] = value;
        else if ( value > res[1] )
            res[1] = value;

        value = max1 * max2;
        if ( value < res[0] )
            res[0] = value;
        else if ( value > res[1] )
            res[1] = value;
    }


    private void evalX( long min1, long max1, long min2, long max2, long[] res )
    { 
        // Sum: min
        res[0] = min1 + min2;

        // Sum: max
        res[1] = max1 + max2;

        // Diff: min
        long value = min1 - max2;
        if ( value < res[0] )
            res[0] = value;

        // Diff: max
        value = max1 - min2;
        if ( value > res[1] )
            res[1] = value;

        // Prod: min and max
        value = min1 * min2;
        if ( value < res[0] )
            res[0] = value;
        else if ( value > res[1] )
            res[1] = value;

        value = min1 * max2;
        if ( value < res[0] )
            res[0] = value;
        else if ( value > res[1] )
            res[1] = value;

        value = max1 * min2;
        if ( value < res[0] )
            res[0] = value;
        else if ( value > res[1] )
            res[1] = value;

        value = max1 * max2;
        if ( value < res[0] )
            res[0] = value;
        else if ( value > res[1] )
            res[1] = value;
    }


    public static void main( String[] args ) throws IOException
    {
        BufferedReader input = 
            new BufferedReader( new InputStreamReader(System.in) );

        int seqLength = Integer.parseInt( input.readLine() );
        SafeSecret evaluator = new SafeSecret(seqLength);
            
        StringTokenizer line = new StringTokenizer( input.readLine() );
        for ( int i = 0; i < seqLength; i++ )
        {
            int number = Integer.parseInt( line.nextToken() );
            char op = line.nextToken().charAt(0);
            evaluator.addPair(i, number, op);
        }
        input.close();

        long[][] minMax = evaluator.computeMinMax();

        int lastPos = seqLength - 1;
        for ( int i = 0; i < lastPos; i++ )
        { 
            System.out.print( Math.abs( minMax[i][0] ) );
            System.out.print( Math.abs( minMax[i][1] ) );
        }
        System.out.print( Math.abs( minMax[lastPos][0] ) );
        System.out.println( Math.abs( minMax[lastPos][1] ) );
    }


}
