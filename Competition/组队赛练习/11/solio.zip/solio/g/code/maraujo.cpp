// Miguel Araujo
#include <cstdio>
#include <vector>
#include <algorithm>
#include <map>
#include <set>

#define MAXN 500
#define MAXK 3000

using namespace std;

int n1, n2, n;

pair<int, int> p1[MAXN], p2[MAXN];
set<int> x1, x2, y, y2;
map<int, int> mx1, mx2, my1, my2;

bool isRight(int initial) {
  for (int i = 0; i < n; i++)
    if (mx1[p1[i].first] != mx2[p2[(i+initial)%n].first] || my1[p1[i].second] != my2[p2[(i+initial)%n].second])
      return false;
  return true;
}

void rotate() {
  //puts("Rotating");
  for (int i = 0; i < n; i++) {
    int tmp = p2[i].first;
    p2[i].first = -p2[i].second;
    p2[i].second = tmp;
  }
}

bool solve() {
  x1.clear(); x2.clear(); y.clear(); y2.clear();
  for (int i = 0; i < n; i++) {
    x1.insert(p1[i].first);
    y.insert(p1[i].second);
    x2.insert(p2[i].first);
    y2.insert(p2[i].second);
  }

  mx1.clear(); mx2.clear(); my1.clear(); my2.clear();
  int cnt = 0;
  for (set<int>::iterator it = x1.begin(); it != x1.end(); it++) 
    mx1[*it] = cnt++;
  cnt = 0;
  for (set<int>::iterator it = x2.begin(); it != x2.end(); it++) 
    mx2[*it] = cnt++;
  cnt = 0;
  for (set<int>::iterator it = y.begin(); it != y.end(); it++) 
    my1[*it] = cnt++;
  cnt = 0;
  for (set<int>::iterator it = y2.begin(); it != y2.end(); it++) 
    my2[*it] = cnt++;
  
  int initial = -1, mx = mx1[p1[0].first], my = my1[p1[0].second];
  //printf("mx = %d, my = %d\n", mx, my);
  for (int i = 0; i < n; i++)
    if (mx2[p2[i].first] == mx && my2[p2[i].second] == my) {
      initial = i;
      break;
    }
  if (initial == -1) 
    return false;
  //printf("Initial = %d\n", initial);
  return isRight(initial);
}

int main() {
  scanf("%d", &n1);
  for (int i = 0; i < n1; i++)
    scanf("%d %d", &p1[i].first, &p1[i].second);
  
  scanf("%d", &n2);
  for (int i = 0; i < n2; i++)
    scanf("%d %d", &p2[i].first, &p2[i].second);

  if (n1 != n2) { puts("no"); return 0; }
  n = n1;

  if (solve()) puts("yes");
  else {
    rotate();
    if (solve()) puts("yes");
    else {
      rotate();
      if (solve()) puts("yes");
      else {
	rotate();
	if (solve()) puts("yes");
	else
	  puts("no");
      }
    }
  }

  return 0;
}
