//-------------------------------------------
//  By Ana Paula Tomas  (p9)
//-------------------------------------------
#include <stdio.h>

#define MAXVERTS  500
#define MAXCOORDS 3000
// simple version (3000 discards the need to sort edges in O(n log n))

#define FREELINE -1

typedef struct ponto {
  int x, y;
} PONTO;

#define XCOORD(P) ((P).x)
#define YCOORD(P) ((P).y)

int read_polygon(PONTO pol[],int box[]);
void polygon2permutomino(PONTO *pol,int n,int box[]);
int is_equal(int n,PONTO *p1,PONTO *p2,int box1[],int box2[]);
int is_rotation(int rot,int n,PONTO p1[],PONTO p2[],int box1[],int box2[]);
PONTO rotate_point(int rot, int c, PONTO p);



int Hgrid[MAXCOORDS+1], Vgrid[MAXCOORDS+1];

// reads a polygon and determines its minimum bounding box
int read_polygon(PONTO pol[],int box[]) {
  int n, i, maxX, maxY, horizontal;

  scanf("%d",&n);
  scanf("%d %d",&XCOORD(pol[0]),&YCOORD(pol[0]));
  // minX = 0;  minY = 0; 
  box[0] = 0;
  if (XCOORD(pol[0]) == 0) box[3] = n-1;
  maxX = 0; maxY = 0;  horizontal = 1;
  for(i=1; i< n; i++) {
    scanf("%d %d",&XCOORD(pol[i]), &YCOORD(pol[i]));
    if (horizontal == 1) {
      if (YCOORD(pol[i]) > maxY) {
	maxY = YCOORD(pol[i]);
        box[2] = i-1;
      }
    } else {
      if (XCOORD(pol[i]) == 0) box[3] = i-1;
      else if (XCOORD(pol[i]) > maxX) {
	  maxX = XCOORD(pol[i]);
          box[1] = i-1;
      }
    }
    horizontal = -horizontal;   // H to V or V to H
  }
  return  n;
}

// removes empty gridlines to obtain the permutomino
void  polygon2permutomino(PONTO *pol,int n,int box[]) {
  int i, j;

  // in a permutomino, xmax and ymax ==  (n-2)/2 
  if (XCOORD(pol[box[1]]) != (n-2)/2 || YCOORD(pol[box[2]]) != (n-2)/2) {
    // some horizontal or vertical grid lines are free
    for(i=0;i<MAXCOORDS+1;i++) 
      Hgrid[i] = Vgrid[i] = FREELINE;
    
    for(i=0; i < n; i=i+2) {
      Hgrid[YCOORD(pol[i])] = i;
      Vgrid[XCOORD(pol[i+1])] = i+1;
    }
    
    // shift downwards
    if (YCOORD(pol[box[2]]) != (n-2)/2) {
      for(i=j=0; i< n/2; j++) {     
	// mmbox of a permutomino has n/2 lines
	if (Hgrid[j] != FREELINE) {
	  YCOORD(pol[Hgrid[j]]) = i;
	  YCOORD(pol[(Hgrid[j]+1)%n]) = i;
	  i++;
	}
      }
    }

    // shift to the left
    if (XCOORD(pol[box[1]]) != (n-2)/2) {
      for(i=j=0; i< n/2; j++) {     
	// mmbox of a permutomino has n/2 lines
	if (Vgrid[j] != FREELINE) {
	  XCOORD(pol[Vgrid[j]])  = i;
	  XCOORD(pol[(Vgrid[j]+1)%n])  = i;
	  i++;
	}
      }
    }
  }
}

// to find the coordinates of p by rotation rot*90 CCW (w.r.t. the initial referential system) 
PONTO rotate_point(int rot, int c, PONTO p) {
  // transf.for testing (equation already solved)
  PONTO pf;
  switch(rot) {
  case 1:   //90 ccw
    XCOORD(pf) = c-YCOORD(p);   
    YCOORD(pf) = XCOORD(p);
    break;
  case 2:  // 180 ccw
    XCOORD(pf) = -XCOORD(p) + c;   
    YCOORD(pf) = -YCOORD(p) + c;
    break;
  default:   // 270 ccw  case 3
    XCOORD(pf) = YCOORD(p);
    YCOORD(pf)  = -XCOORD(p) + c;
   }
  return pf;
}

// checks whether the two permutominoes coincide (as fixed permutominoes)
int is_equal(int n,PONTO *p1,PONTO *p2,int box1[],int box2[]) 
{
  int i, j, k;

  // filtering step: check the edges on the bounding square
  for(i=0; i < 4; i++) {
    if (XCOORD(p1[box1[i]]) != XCOORD(p2[box2[i]]) || YCOORD(p1[box1[i]]) != YCOORD(p2[box2[i]]))
      return 0;
    // check the other extreme point
    j = (1+box1[i])%n;  
    k = (1+box2[i])%n;  
    if (XCOORD(p1[j]) != XCOORD(p2[k]) || YCOORD(p1[j]) != YCOORD(p2[k]))
      return 0;
  }

  // if the bounding squares fit, check all vertices
  for(i=0; i < n; i++) 
    if (XCOORD(p1[i]) != XCOORD(p2[i]) || YCOORD(p1[i]) != YCOORD(p2[i]))
      return 0;
    
  return 1;
}




int is_rotation(int rot,int n,PONTO p1[],PONTO p2[],int box1[],int box2[])
{
  int i, j, c = n/2-1;
  PONTO v;

  // filtering step: check the edges on the bounding square
  for(i=0; i < 4; i++) {
    v = rotate_point(rot,c,p1[box1[i]]);
    j = box2[(i+rot)%4];
    if (XCOORD(p2[j]) != XCOORD(v) || YCOORD(p2[j]) != YCOORD(v))
      return 0;
    v = rotate_point(rot,c,p1[(1+box1[i])%n]);
    j = (j+1)%n;
    if (XCOORD(p2[j]) != XCOORD(v) || YCOORD(p2[j]) != YCOORD(v))
      return 0;
  }

  // if the bounding squares fit, check all vertices
  for(i=0; i < n; i++) {
    v = rotate_point(rot,c,p1[i]);
    j = (i+box2[rot])%n;
    if (XCOORD(p2[j]) != XCOORD(v) || YCOORD(p2[j]) != YCOORD(v))
      return 0;
  }

  return 1;
}


int main() {
  int n1, n2, okrot = 0, rot;
  PONTO p1[MAXVERTS], p2[MAXVERTS];
  int box1[4], box2[4];  

  n1 = read_polygon(p1,box1);
  n2 = read_polygon(p2,box2);

  if (n1 == n2){ 
    polygon2permutomino(p1,n1,box1);
    polygon2permutomino(p2,n2,box2);
    okrot = is_equal(n1,p1,p2,box1,box2);
    for(rot=1; rot<4 && !okrot; rot++)
      okrot = is_rotation(rot,n1,p1,p2,box1,box2);
  }

  if (okrot)  printf("yes\n");
  else printf("no\n");

  return 0;
}


