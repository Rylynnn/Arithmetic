// SWERC 2014, Problem Playing with Geometry
// Approach: Skrink the given polygons to the corresponding permutonino.
//           Then rotate one of the permutonimos and check if it is the same as the other.
// Author: Miguel Oliveira
import java.io.*;
import java.util.*;

public class PlayingWithGeometry {
  static BufferedReader input = new BufferedReader( new InputStreamReader(System.in) );
  
  static class Polygon {
    int n;
    int[] y;
    int[] x;

    Polygon(int n) {
      this.n = n;
      y = new int[n];
      x = new int[n];
    }
    void shrink(int[] vec) {
      TreeMap<Integer, Integer> map = new TreeMap<Integer, Integer>();
      for (int val : vec)
        map.put(val, 0);
      int ind = 0;
      for (Map.Entry<Integer,Integer> entry : map.entrySet()) {
        entry.setValue(ind++);
      }
      for (int i = 0; i < vec.length; i++)
        vec[i] = map.get(vec[i]);
    }
    void shrink() {
      shrink(y);
      shrink(x);
    }
    void rotate() {
      for (int i = 0; i < this.n; i++) {
        int t = x[i];
        x[i] = -y[i];
        y[i] = t;
      }
      shrink();
    }
    boolean equals(Polygon b) {
      if (this.n != b.n)
        return false;
      int start = 0, minx = Integer.MAX_VALUE;
      for (int i = 0; i < n; i++)
        if (b.y[i] == 0 && b.x[i] < minx) {
          start = i;
          minx = b.x[i];
        }
      for (int i = 0; i < n; i++)
        if (x[i] != b.x[(i+start)%n] || y[i] != b.y[(i+start)%n])
          return false;
      return true;
    }
  }

  static Polygon readAndShrinkPolygon() throws IOException {
    StringTokenizer line = new StringTokenizer( input.readLine() );
    int n = Integer.parseInt(line.nextToken());
    Polygon p = new Polygon(n);
    for (int i = 0; i < n; i++) {
      p.x[i] = Integer.parseInt(line.nextToken());
      p.y[i] = Integer.parseInt(line.nextToken());
    }
    p.shrink();
    return p;
  }
  static boolean Check(Polygon a, Polygon b) {
    for (int i = 0; i < 4; i++) {
      if (a.equals(b))
        return true;
      b.rotate();
    }
    return false;
  }
  public static void main(String[] args) throws IOException {
    Polygon a = readAndShrinkPolygon();
    Polygon b = readAndShrinkPolygon();
    if (Check(a, b))
      System.out.println("yes");
    else
      System.out.println("no");
  }
}
