// SWERC 2014, Problem City Park
// Approach: Sweep line to find adjacent rectangles and Union-Find to group them in surfaces. 
// Author: Miguel Oliveira
#include <cstdio>
#include <algorithm>
#include <set>
#include <vector>
using namespace std;
const int MAX = 50000+1;

struct Rectangle {
  int x, y, x2, y2, area, group, num_neighbors;
  bool Intersects(const Rectangle& r) { return (x <= r.x2 && x2 >= r.x && y <= r.y2 && y2 >= r.y); }
  bool operator < (const Rectangle& r) const {
    if (x != r.x)     return x < r.x;
    if (y != r.y)     return y < r.y;
    if (x2 != r.x2)   return x2 < r.x2;
    return y2 < r.y2;
  }
} rectangles[MAX];

struct Event {
  int y, y2, x, ind;
  char is_finish;
  Event(int i=0, int _x=0, int _y=0, int _y2=0, char _tipo=0) {
    ind = i, x = _x, y = _y, y2 = _y2, is_finish = _tipo;
  }
  bool operator < (const Event& e) const {
    if (x != e.x)                  return x < e.x;
    if (is_finish != e.is_finish)  return is_finish < e.is_finish; // start first.
    if (y != e.y)                  return y < e.y;
    return y2 < e.y2;
  }
} events[2*MAX];

struct TreeNode {
  int ind, y, y2;
  TreeNode(int i=0, int a = 0, int b = 0) {
    ind = i, y = a, y2 = b;
  }
  bool operator < (const TreeNode& t) const {
    if (y != t.y)       return y < t.y;
    if (y2 != t.y2)     return y2 < t.y2;
    return ind < t.ind;
  }
};

int parent[MAX], prank[MAX], area[MAX]; 

int FindSet(int x) {
  if (x != parent[x])
    return parent[x] = FindSet(parent[x]);
  return x;
}
void Link(int x, int y) {
  if (x == y)
    return;
  if (prank[x] >= prank[y]) {
    parent[y] = x;
    if (prank[x] == prank[y])
      prank[x]++;
  } else
    parent[x] = y;
}

int main() {
  int n, i, w, h, j, ne=0;
  scanf("%d", &n);
  for (i = 0; i < n; i++) {
    scanf("%d %d %d %d", &rectangles[i].x, &rectangles[i].y, &w, &h);
    rectangles[i].x2 = rectangles[i].x + w;
    rectangles[i].y2 = rectangles[i].y + h;
    rectangles[i].area = h * w;
    events[ne++] = Event(i, rectangles[i].x, rectangles[i].y, rectangles[i].y2, 0);
    events[ne++] = Event(i, rectangles[i].x2, rectangles[i].y, rectangles[i].y2, 1);
    parent[i] = i;
  }
  sort(events, events+ne);
  set<TreeNode> s;
  set<TreeNode>::iterator it;
  for (i = 0; i < ne; i++) {
    if (events[i].is_finish) {
      s.erase(TreeNode(events[i].ind, events[i].y, events[i].y2));
    } else {
      TreeNode cur(events[i].ind, events[i].y, events[i].y2);
      it = s.lower_bound(cur);
      if (it != s.begin())
        --it;
      vector<TreeNode> to_remove;
      for (; it != s.end() && it->y <= cur.y2; it++) {
        if (it->y  <= cur.y2 && it->y2 >= cur.y) {
          if (it->y >= cur.y && it->y2 <= cur.y2)
            to_remove.emplace_back(*it);
          Link(FindSet(it->ind), FindSet(cur.ind));
        }
      }
      for (auto& x : to_remove)
        s.erase(x);
      s.insert(cur);
    }
  }
  int res = 0;
  for (i = 0; i < n; i++) {
    j = FindSet(i);
    area[j] += rectangles[i].area;
    res = max(res, area[j]);
  }
  printf("%d\n", res);
  return 0;
}
