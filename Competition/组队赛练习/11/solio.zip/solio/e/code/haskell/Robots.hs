{-# LANGUAGE RecordWildCards, PatternGuards #-}
import           Data.Hashable
import           Data.HashSet (HashSet)
import qualified Data.HashSet as HashSet

import           Data.Char (isDigit)
import           Data.List
import           Data.Maybe
import           Control.Monad

import           System.Random
import           Test.QuickCheck

-- strict 2D vectors
data Vec = Vec !Int !Int deriving (Eq, Ord, Show)

instance Hashable Vec where
  hashWithSalt s (Vec x y) = s `hashWithSalt` x `hashWithSalt` y

instance Num Vec where
  Vec x y + Vec x' y' = Vec (x+x') (y+y')
  Vec x y - Vec x' y' = Vec (x-x') (y-y')  
  negate (Vec x y)    = Vec (-x) (-y)
  (*)                 = error "Vector multiplication undefined"
  fromInteger         = error "Vector fromInteger undefined"
  abs                 = error "Vector abs undefined"
  signum              = error "Vector signum undefined"


-- positions and movement directions are vectors
type Pos = Vec
type Dir = Vec

type Robots = [Pos]

-- board description
data Board = Board { width :: !Int           -- board dimensions
                   , height :: !Int
                   , walls :: HashSet Pos    -- fixed obstacles
                   } deriving Show


-- check board boundaries
inside :: Pos -> Board -> Bool
{-# INLINE inside #-}
(Vec x y) `inside` Board{..} = x>=0 && y>=0 && x<width && y<height


-- check if a position is not obstructed
validPos :: Board -> Robots -> Pos -> Bool
validPos board@Board{..} robots pos
  = pos `inside` board &&
    not (pos `elem` robots ||
         pos `HashSet.member` walls)
                       

-- the four orthogonal directions
directions :: [Dir]
directions = [Vec 0 1, Vec 0 (-1), Vec (-1) 0, Vec 1 0]


-- next robot positions from the current position
moveRobots :: Board -> Robots -> [Robots]
moveRobots board@Board{..} robots
  = do (prev, pos:next) <- split robots
       dir <- directions                           -- all valid directions
       let pos' = moveUntil board robots pos dir   -- new position
       guard (pos' /= pos)
       return (prev ++ pos':next)
  where
    -- possible splits of a list
    split xs  = zip (inits xs) (tails xs)


-- move a robot until it hits an obstacle 
moveUntil :: Board -> Robots -> Pos -> Dir -> Pos
moveUntil board@Board{..} robots pos dir
  = loop pos (pos+dir)
  where loop p p' | validPos board robots p' = loop p' (p'+dir)
                  | otherwise                = p


-- complete problem statement
data Problem = Problem { board :: Board     -- board description
                       , initial :: Robots  -- initial robot positions
                       , target :: Pos      -- target position for R1
                       , maxMoves :: Int    -- maximum moves
                       } deriving Show



-- forward BFS solver
-- it is critical to use an efficient data structure (HashSet)
-- to remove duplicate robot posititions
bfs_solve :: Problem -> Maybe Int
bfs_solve Problem{..}
  =  listToMaybe [i | (i,robots)<-zip [0..maxMoves] reachable,
                  check target robots]
  where 
        -- reachable states after sucessives moves
        reachable = takeWhile (not . null) $
                    map fst $
                    iterate transition ([initial], HashSet.singleton initial)
        -- state transition function 
        transition (robots, visited) =
          let neighbours = HashSet.fromList $
                           concatMap (moveRobots board) robots
              neighbours'= HashSet.difference neighbours visited
              visited'= HashSet.union neighbours' visited
              robots' = HashSet.toList neighbours'
          in (robots', visited')




-- check a solution
check :: Pos ->  [Robots] -> Bool
check target robots = any (target==) (map head robots)


{-
-- limited depth DFS solver
-- find optimal solution by doing DFS with increasing limit on the depth
-- this is slower than the BFS above but runs in bounded space
dfs_solve :: Problem -> Maybe Int
dfs_solve Problem{..}
  = listToMaybe [i | i<-[0..maxMoves], dfs i initial HashSet.empty]
  where
    dfs n robots visited
      | n>0       = or [dfs (n-1) robots' (HashSet.insert robots visited)
                       | robots'<-moveRobots board robots,
                         not (robots' `HashSet.member` visited)
                        ]
      | otherwise = head robots == target
-}






----------------------------------------------------------------------------
-- QuickCheck generators
---------------------------------------------------------------------------
-- for testing only

-- an empty board
empty :: Int -> Int -> Board
empty w h = Board  { walls = HashSet.empty
                   , width = w
                   , height= h
                   }


genRobots :: Board -> Int -> Gen Robots
genRobots Board{..} n = 
  vectorOf n (genPos width height) `suchThat`
    (\pos -> distinct pos && not (any (`HashSet.member`walls) pos))
  where distinct xs = length (nub xs) == n

-- generator for boards
genBoard :: Int -> Int -> Int -> Gen Board
genBoard w h n  -- width, height, number of walls
  = do pos <- vectorOf n (genPos w h)
       return Board { width = w
                    , height = h
                    , walls = HashSet.fromList pos
                    }


-- generate positions and directions
genPos :: Int -> Int -> Gen Pos
genPos w h = liftM2 Vec (choose (0, w-1)) (choose (0, h-1))

genDir = elements directions


genProb :: Int -> Int -> Int -> Int -> Gen Problem
genProb w h numRobots numWalls 
    = do b <- genBoard w h numWalls
         -- choose robots and target position
         pos:robots <- genRobots b (1+numRobots) 
         return Problem { board = b
                        , initial = robots
                        , target = pos
                        , maxMoves = 10
                        }
                   


wall_neighbours :: Board -> HashSet Pos
wall_neighbours board@Board{..} = 
    HashSet.fromList $
    filter (`inside`board) $ 
    concatMap neighbs (HashSet.toList walls)
    where neighbs pos = [pos+dir | dir<-directions]



-- run a generator
runGen :: Gen a -> IO a
runGen g = liftM head (sample' g)

------------------------------------------------------------
-- make random test inputs
------------------------------------------------------------
writeTests :: StdGen -> IO ()
writeTests stdgen = do
  setStdGen stdgen
  writeFile "random.stdgen" (show stdgen)
  probs1 <- sample' (genProb 8 8 4 12)
  probs2 <- sample' (genProb 8 8 4 12)
  sequence_ [ writeFile ("random" ++ show i ) (showProblem p)
            | (i,p)<-zip [1..] (probs1++probs2)
            ]
  


------------------------------------------------------------------------
-- problem pretty printing & reading
------------------------------------------------------------------------
showProblem :: Problem -> String
showProblem Problem{..} = unlines $ first : map showRow [0..h-1]
  where
    n = length initial -- number of robots
    h = height board   -- board dimensions
    w = width board
    first = unwords $ map show [n, h, w, maxMoves]
    showRow y = [charAt (Vec x y) | x <-[0..w-1]]
    charAt pos
      | pos == target = 'X'
      | HashSet.member pos (walls board) = 'W'
      | Just i <- elemIndex pos initial  = head (show (1+i))
                                                 -- robot number 1..4
      | otherwise = '.'




readProblem :: String -> Problem
readProblem txt
  | h /= length rows || any (/=w) (map length rows)
        = error "readProblem: inconsistent size"
  | null ts = error "readProblem: no target"
  | null rs = error "readProblem: no robots"
  | otherwise = Problem { board = Board { walls = HashSet.fromList ws
                                        , width = w
                                        , height = h
                             }
                        , initial = rs
                        , target = head ts
                        , maxMoves = m
                        }
  where first:rows = lines txt
        [n,w,h,m]  = map read (words first)
        -- filter positions given a predicate
        positions p = [ (Vec x y, c) |
                        (y,row)<-zip [0..] rows,
                        (x,c) <- zip [0..] row, p c ]
        ws = map fst $ positions (=='W')
        rs = map fst $ 
             sortBy (\x y -> compare (snd x) (snd y)) $ 
             positions isDigit
        ts = map fst $ positions (=='X')


main :: IO ()
main = do 
  problem <- fmap readProblem getContents
  putStrLn $ maybe "NO SOLUTION" show $ bfs_solve problem

