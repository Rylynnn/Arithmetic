// SWERC 2014, Problem Ricochet Robots
// Approach: Breadth First Search using the robots positions as states
// Author: Miguel Oliveira
#include <algorithm>
#include <iostream>
#include <vector>
#include <queue>
#include <map>
using namespace std;
const int MAX = 16;

map<vector<pair<int, int> >, int> seen;
char grid[MAX][MAX+1];
int w, h, limit, dirx[] = {0, 0, 1, -1}, diry[] = {1, -1, 0, 0};

inline void Push(queue<vector<pair<int, int> > >& q, vector<pair<int, int> >& robots, int moves) {
    sort(robots.begin()+1, robots.end());  // The order of the other robots does not matter.
    if (seen.find(robots) == seen.end()) {
        q.push(robots);
        seen[robots] = moves;
    }
}

void MoveRobot(vector<pair<int, int> >& robots, size_t i, int dy, int dx) {
    int y = robots[i].first + dy, x = robots[i].second + dx, bad = false;
    for (; y >= 0 && x >= 0 && y < h && x < w; y += dy, x += dx) {
        if (grid[y][x] == 'W')
            break;
        for (size_t j = 0; j < robots.size(); j++)
            if (i != j && robots[j].first == y && robots[j].second == x)
                bad = true;
        if (bad)
            break;
    }
    robots[i] = make_pair(y-dy, x-dx);
}

int Bfs(vector<pair<int, int> >& robots) {
    queue<vector<pair<int, int> > > q;
    Push(q, robots, 0);
    while (!q.empty()) {
        const vector<pair<int, int> > cur = q.front();
        q.pop();
        int moves = seen[cur];
        if (grid[cur[0].first][cur[0].second] == 'X')
            return moves;
        if (moves == limit)
            continue;
        for (size_t k = 0; k < cur.size(); k++) {   // Move robot k
            for (int d = 0; d < 4; d++) {           // in direction d
                vector<pair<int, int> > state = cur;
                MoveRobot(state, k, diry[d], dirx[d]);
                Push(q, state, moves+1);
            }
        }
    }
    return -1;
}

int main() {
  int i, j, k;
  cin >> k >> w >> h >> limit;
    vector<pair<int, int> > robots(1);
    for (i = 0; i < h; i++) {
        cin >> grid[i];
        for (j = 0; j < w; j++)
            if (grid[i][j] >= '1' && grid[i][j] <= '4') {
                if (grid[i][j] == '1')
                    robots[0] = make_pair(i, j);
                else
                    robots.push_back(make_pair(i,j));
            }
    }
    int res = Bfs(robots);
    if (res == -1)      cout << "NO SOLUTION" << endl;
    else                cout << res << endl;
    return 0;
}
