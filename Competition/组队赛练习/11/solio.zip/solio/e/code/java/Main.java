
import java.util.*;
import java.math.*;

class Position {
	public int x;
	public int y;
	
	public Position(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Position(Position pos) {
		this.x = pos.x;
		this.y = pos.y;
	}


	@Override
	public String toString() {
		return "Position [x=" + x + ", y=" + y + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Position other = (Position) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}
	
	// mutator method: move a single space in a given direction
	public void moveOne(Direction dir) {
		assert(dir != null);
		switch(dir) {
		case UP:
			y += 1;
			break;
		case DOWN: 
			y -= 1;
			break;
		case LEFT: 
			x -= 1;
			break;
		case RIGHT: 
			x += 1;
		}
	}
}


enum Direction {
	UP, DOWN, LEFT, RIGHT ;
};

class Robots {
	private Position[] positions;  // positions of each robot
	private int moves;             // number of moves done to reach this state
	
	public Robots(Position[] positions) {  // starting position for robots
		assert(positions != null);
		for(int i=0; i<positions.length; i++)
			assert(positions[i] != null);
		this.positions = positions;
		this.moves = 0;
	}
	
	
	public Robots(Robots robots) {
		assert(robots != null);
		this.positions = new Position[robots.positions.length];
		for(int i = 0; i<positions.length; i++)
			this.positions[i] = new Position(robots.positions[i]);
		this.moves = robots.moves;
	}
	
public void move(int i, Position pos) {  // move the i-th robot into a new position
		positions[i] = pos;
		this.moves += 1;  // count an extra move
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 0;
		for (int i=0; i<positions.length; i++)
			result = prime * result + positions[i].hashCode();
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Robots other = (Robots) obj;
		if (!Arrays.equals(positions, other.positions))
			return false;
		return true;
	}

	public Position[] getPositions() {
		return positions;
	}
	

	public int getMoves() {
		return moves;
	}
	
	public boolean contains(Position pos) {
		for (int i=0; i<positions.length; i++) {
			if (pos.equals(positions[i]))
				return true;
		}
		return false;
	}
	
	public boolean reached(Position pos) {  // check if first robot reached a position
		return positions[0].equals(pos);
	}

	@Override
	public String toString() {
		return "Robots [positions=" + Arrays.toString(positions) + ", moves="
				+ moves + "]";
	}
}

public class Main {
    static Robots robots;
    static Position target;
    static int maxMoves;
    static int width;
    static int height;
    static Set<Position> walls;       
    static Set<Robots> visited;
    static Queue<Robots> queue;
    
    public static boolean hasNext() {
	return !queue.isEmpty();
    }
 
    public static Robots next() {
	//removes from front of queue
	Robots next = queue.remove(); 
	for (Robots neighbor : moveRobots(next)) {
	    if (!visited.contains(neighbor)) {
		queue.add(neighbor);
		visited.add(neighbor);
	    }
	}
	return next;
    }


    /*public Board(int width, int height) {
		this.width = width;
		this.height = height;
		this.walls = new HashSet<Position>();
		}*/
	
	public static void setWall(Position pos) {
		assert(pos != null);
		walls.add(pos);
	}
	
	public static boolean inside(Position pos) {
		assert(pos != null);
		return (pos.x >= 0 && pos.x < width &&
				pos.y >= 0 && pos.y < height);
	}
	
	public static boolean valid(Position pos, Robots robots) {
		assert(pos != null);
		if (!inside(pos))
			return false;
		if (walls.contains(pos) || robots.contains(pos))
			return false;
		return true;
	}
	
	/* move until we hit an obstacle */
	public static Position moveUntil(Robots robots, Position pos, Direction dir) {
		Position next = new Position(pos);
		Position prev = new Position(pos);
		next.moveOne(dir);
		while(valid(next, robots)) {
			next.moveOne(dir);
			prev.moveOne(dir);
		}
		return prev;
	}

	/* immediate new positions for robots */
	public static List<Robots> moveRobots(Robots robots) {
		Position[] positions = robots.getPositions();
		List<Robots> nexts = new ArrayList<Robots>();  
		
		for (int i=0; i<positions.length; i++) {
			for (Direction dir : Direction.values()) {
				Position newpos = moveUntil(robots, positions[i], dir);
				if (!newpos.equals(positions[i])) {
					Robots next = new Robots(robots);
					next.move(i, newpos);
					nexts.add(next);
				}
			}
		}
		return nexts;
	}
	
		

	
	public static void readProblem() {
		Scanner sc = new Scanner(System.in);
		int w, h, numRobots;
		
		numRobots = sc.nextInt();  // number of robots
		w = sc.nextInt();  // board dimensions
		h = sc.nextInt();
		maxMoves = sc.nextInt();   // search depth
		sc.nextLine();

		width = w;
		height = h;
		walls = new HashSet<Position>();
		Position[] positions = new Position[numRobots];
		
		for(int y=0; y<h; y++) {
			String line = sc.nextLine();
			// System.out.println(line);
			for (int x=0; x<line.length(); x++) {
				char c = line.charAt(x);
				if(c == 'W') 
					setWall(new Position(x,y));
				else if(c == 'X') 
					target = new Position(x,y);
				else if(Character.isDigit(c)){
					int i = Character.digit(c, 10);
					positions[i-1] = new Position(x,y);
				}
			}
		}
		sc.close();
		
		robots = new Robots(positions);
		
		/*
		System.out.println("Width = " + w);
		System.out.println("Height = " + h);
		System.out.println("maxMoves = " + maxMoves);
		System.out.println("numRobots = " + numRobots);
		*/
	}
	
	
	public static void main(String args[]) {
		readProblem();
		// assert(board != null);
		assert(robots != null);
		visited = new HashSet<Robots>();
		queue = new LinkedList<Robots>();
		    // BFS bfs = new BFS(robots);
		queue.add(robots);
		visited.add(robots);
		
		boolean found = false;
		int moves = 0;
		while (!found && moves<=maxMoves && hasNext()) {
			Robots next = next();
			found = next.reached(target) ;
			moves = next.getMoves();
		}
		if(found) {
		    System.out.println(moves);
		} else {
		    System.out.println("NO SOLUTION");
		}		    
		
	}
}





