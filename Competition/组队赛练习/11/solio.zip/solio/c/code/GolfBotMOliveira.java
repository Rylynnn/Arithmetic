// SWERC 2014, Problem Golf Bot
// Approach: Fast Fourier Transform.
// Author: Miguel Oliveira

import java.io.*;
import java.util.StringTokenizer;

public class GolfBotMOliveira {
  public static void main(String[] args) throws IOException {
    BufferedReader input = new BufferedReader( new InputStreamReader(System.in) );
    StringTokenizer line = new StringTokenizer( input.readLine() );

    int i, n = Integer.parseInt(line.nextToken());
    int[] shots = new int[n];
    for (i = 0; i < n; i++) {
      shots[i] = Integer.parseInt(input.readLine());
    }
    int m = Integer.parseInt(input.readLine()), maxDist = 0;
    int[] holes = new int[m];
    for (i = 0; i < m; i++) {
      holes[i] = Integer.parseInt(input.readLine());
      if (holes[i] > maxDist)
        maxDist = holes[i];
    }
    long[] a = new long[maxDist+1];
    a[0] = 1;
    for (i = 0; i < n; i++)
      if (shots[i] <= maxDist)
        a[shots[i]] = 1;
    boolean[] hasHole = new boolean[maxDist+1];
    for (i = 0; i < m; i++)
      hasHole[holes[i]] = true;

    long[] c = FastFourierTransform.multiply(a, a);
    int res = 0;
    /*
    for (i = 0; i <= maxDist; i++)
      System.out.println(i + ") " + hasHole[i] + " " + c[i]);
    */
    for (i = 1; i <= maxDist; i++)
      if (c[i] > 0 && hasHole[i])
        res++;
    System.out.println(res);
  }
}

class FastFourierTransform {
  public static void fft(double[] a, double[] b, boolean invert) {
    int count = a.length;
    for (int i = 1, j = 0; i < count; i++) {
      int bit = count >> 1;
      for (; j >= bit; bit >>= 1)
        j -= bit;
      j += bit;
      if (i < j) {
        double temp = a[i];
        a[i] = a[j];
        a[j] = temp;
        temp = b[i];
        b[i] = b[j];
        b[j] = temp;
      }
    }
    for (int len = 2; len <= count; len <<= 1) {
      int halfLen = len >> 1;
      double angle = 2 * Math.PI / len;
      if (invert)
        angle = -angle;
      double wLenA = Math.cos(angle);
      double wLenB = Math.sin(angle);
      for (int i = 0; i < count; i += len) {
        double wA = 1;
        double wB = 0;
        for (int j = 0; j < halfLen; j++) {
          double uA = a[i + j];
          double uB = b[i + j];
          double vA = a[i + j + halfLen] * wA - b[i + j + halfLen] * wB;
          double vB = a[i + j + halfLen] * wB + b[i + j + halfLen] * wA;
          a[i + j] = uA + vA;
          b[i + j] = uB + vB;
          a[i + j + halfLen] = uA - vA;
          b[i + j + halfLen] = uB - vB;
          double nextWA = wA * wLenA - wB * wLenB;
          wB = wA * wLenB + wB * wLenA;
          wA = nextWA;
        }
      }
    }
    if (invert) {
      for (int i = 0; i < count; i++) {
        a[i] /= count;
        b[i] /= count;
      }
    }
  }

  public static long[] multiply(long[] a, long[] b) {
    int resultSize = Integer.highestOneBit(Math.max(a.length, b.length) - 1) << 2;
    resultSize = Math.max(resultSize, 1);
    double[] aReal = new double[resultSize];
    double[] aImaginary = new double[resultSize];
    double[] bReal = new double[resultSize];
    double[] bImaginary = new double[resultSize];
    for (int i = 0; i < a.length; i++)
      aReal[i] = a[i];
    for (int i = 0; i < b.length; i++)
      bReal[i] = b[i];
    fft(aReal, aImaginary, false);
    if (a == b) {
      System.arraycopy(aReal, 0, bReal, 0, aReal.length);
      System.arraycopy(aImaginary, 0, bImaginary, 0, aImaginary.length);
    } else
      fft(bReal, bImaginary, false);
    for (int i = 0; i < resultSize; i++) {
      double real = aReal[i] * bReal[i] - aImaginary[i] * bImaginary[i];
      aImaginary[i] = aImaginary[i] * bReal[i] + bImaginary[i] * aReal[i];
      aReal[i] = real;
    }
    fft(aReal, aImaginary, true);
    long[] result = new long[resultSize];
    for (int i = 0; i < resultSize; i++)
      result[i] = Math.round(aReal[i]);
    return result;
  }
}
