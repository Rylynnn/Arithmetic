// Miguel Araujo
#include <cassert>
#include <cstdio>
#include <cmath>

#define MAXK (1<<19)

// numeros complexos sao pares de doubles
struct cpx {
  cpx(){}
  cpx(double aa): a(aa){}
  cpx(double aa, double bb): a(aa), b(bb){}
  double a;
  double b;
  double modsq(void) const {
    return a * a + b * b;
  }
  cpx bar(void) const {
    return cpx(a, -b);
  }
};
cpx operator+(cpx a, cpx b) {
  return cpx(a.a + b.a, a.b + b.b);
}
cpx operator*(cpx a, cpx b) {
  return cpx(a.a * b.a - a.b * b.b, a.a * b.b + a.b * b.a);
}
cpx operator/(cpx a, cpx b) {
  cpx r = a * b.bar();
  return cpx(r.a / b.modsq(), r.b / b.modsq());
}
cpx EXP(double theta) {
  return cpx(cos(theta),sin(theta));
}
const double two_pi = 4*acos(0);

int n,m,k; // constantes do input
int vm[MAXK+100]; // numeros do input
int vn[MAXK+100];
cpx a[MAXK+100]; // vn em formato binario
cpx A[MAXK+100], AA[MAXK+100], INV[MAXK+100]; // transformadas e inversas

double cossenos[MAXK+100], senos[MAXK+100];
cpx angle(int dir, int i) {
  return cpx(cossenos[i], dir*senos[i]);
}

void FFT(cpx *in, cpx *out, int step, int size, int dir) {
  if(size < 1) return;
  if(size == 1) {
    out[0] = in[0];
    return;
  }
  FFT(in, out, step * 2, size / 2, dir);
  FFT(in + step, out + size / 2, step * 2, size / 2, dir);
  for(int i = 0 ; i < size / 2 ; i++) {
    cpx even = out[i];
    cpx odd = out[i + size / 2];
    out[i] = even + angle(dir, i*step)*odd; //even + EXP(dir * two_pi * i / size) * odd;
    out[i + size / 2] = even + angle(dir, i*step+MAXK/2)*odd; //even + EXP(dir * two_pi * (i + size / 2) / size) * odd;
  }
}

int main(void) {
  int cnt = 0, temp = 0;
  scanf("%d", &n);
  for (int i = 0; i < n; i++) {
    scanf("%d", &temp);
    vn[temp] = 1;
    a[temp] = 1;
  }
  scanf("%d", &m);
  for (int i = 0; i < m; i++) {
    scanf("%d", &vm[i]);
  }
  
  //tabelar senos/cossenos
  for (int i = 0; i <= MAXK; i++) {
    cossenos[i] = cos(two_pi*i/MAXK);
    senos[i] = sin(two_pi*i/MAXK);
  }

  FFT(a, A, 1, MAXK, 1);
  for (int i = 0; i < MAXK; i++)
    AA[i] = A[i]*A[i];

  FFT(AA, INV, 1, MAXK, -1);

  for (int i=0; i<MAXK; i++)
    INV[i] = INV[i]/MAXK;    

  for (int i = 0; i<m; i++) {
    if (vn[vm[i]])
      cnt++;
    else 
      if (INV[vm[i]].a > 0.5) 
	  cnt++;
  }
  printf("%d\n", cnt);
  return 0;
}
