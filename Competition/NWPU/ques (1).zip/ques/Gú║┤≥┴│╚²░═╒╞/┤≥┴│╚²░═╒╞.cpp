#include <cstdio>
#include <cstring>
#include <algorithm>
#include <climits>
#include <cctype>
#include <map>
#include <list>
#include <iterator>
#include <functional>
#include <queue>
#include <cmath>
#include <set>
#include <stack>
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include<ctime>
#define ff first
#define ss second
#define pu system("pause")
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<char,char> P;

const double pi = acos(-1.0);
const ll inf = 0x7fffffff;
const ll mod = 1e9 + 7;

char s[1000010];

stack <char> st;

map <P,bool> m;

void init()
{
    m[make_pair('[',']')] = 1;
    m[make_pair('(',')')] = 1;
    m[make_pair('{','}')] = 1;
}

int main()
{
    //clock_t start,finish;
    //start=clock();
    //freopen("G_in.txt","r",stdin);
    //freopen("out.txt","w",stdout);
    int t,k = 1;
    scanf("%d",&t);
    init();
    while (t --)
    {
        scanf("%s",s);
        while (!st.empty())
            st.pop();
        bool flag = 1;
        for (int i = 0;s[i]; ++ i)
        {

            if (s[i] == '(' || s[i] == '[' || s[i] == '{')
                st.push(s[i]);
            else if (st.empty())
            {
                flag = 0;
                break;
            }
            else if (m[make_pair(st.top(),s[i])])
            {
                st.pop();
            }
            else
            {
                flag = 0;
                break;
            }
        }
        printf("Case #%d:",k ++);
        puts(flag ? "Yoxi" : "aTAMATATA");
    }
    //finish=clock();
    //printf("%d\n",finish-start);
    return 0;
}
