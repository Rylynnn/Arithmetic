#include <cstdio>
#include <cstring>
#include <algorithm>
#include<ctime>
using namespace std;
int n,m,k,ans;
bool tt[20][20];
int dx[]={0,-1,-1,-1},dy[]={-1,-1,0,1};
inline int g(int a,int b)
{
    return (m-b)/k+(n-a)*(m/k);
}
void dfs(int a,int b,bool f,int cur)
{
    if(a>n)
    {
        if(ans>cur)
        {
            ans=cur;
        }
        return;
    }
    if(cur+g(a,b)>=ans)
        return;
    if(!f)
    {
        int i,x,y,cc;
        for(i=0;i<4;++i)
        {
            cc=0;
            for(x=a,y=b;!tt[x][y];x+=dx[i],y+=dy[i])
                ++cc;
            if(cc>=k)
                return;
        }
    }
    ++b;
    if(b>m)
    {
        b=1;
        ++a;
    }
    dfs(a,b,0,cur);
    tt[a][b]=1;
    dfs(a,b,1,cur+1);
    if(a<=n)
        tt[a][b]=0;
}
int main()
{
    //clock_t start,finish;
    //start=clock();
    //freopen("C_in.txt","r",stdin);
    //freopen("C_out.txt","w",stdout);
    int T,t,i,j;
    scanf("%d",&T);
    for(t=1;t<=T;++t)
    {
        scanf("%d%d%d",&n,&m,&k);
        memset(tt,1,sizeof(tt));
        for(i=1;i<=n;++i)
            for(j=1;j<=m;++j)
                tt[i][j]=0;
        ans=n/k*m+m/k*n-(n/k)*(m/k)+1;
        if(n<k&&m<k)
            ans=0;
        dfs(1,1,0,0);
        tt[1][1]=1;
        dfs(1,1,1,1);
        tt[1][1]=0;
        printf("Case #%d: %d\n",t,ans);
    }
    //finish=clock();
    //printf("[%d]\n",finish-start);
    return 0;
}
