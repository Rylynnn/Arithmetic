#include<cstdio>
#include<cmath>
#include<ctime>
#define maxn 100000
using namespace std;

typedef long long LL;
LL x,y;
int n;
LL a[maxn+5];
LL p1,p2,p3,p4;

LL pow_mod(LL aa,LL ii,LL nn)
{
//    if(ii==0) return 1%nn;
//    LL temp=pow_mod(aa,ii>>1,nn);
//    temp=temp*temp%nn;
//    if(ii&1) temp=temp*aa%nn;
//    return temp;

    if(ii==0) return 1%nn;
    LL temp=1;
    while(ii)
    {
        if(ii&1) temp=temp*aa%nn;
        ii>>=1;
        aa=aa*aa%nn;
    }
    return temp;
}

LL mul_mod(LL aa,LL ii,LL nn)
{
//    if(ii==0) return 0;
//    LL temp=mul_mod(aa,ii>>1,nn);
//    temp=(temp+temp)%nn;
//    if(ii&1) temp=(temp+aa)%nn;
//    return temp%nn;

    if(ii==0) return 0;
    LL temp=0;
    while(ii)
    {
        if(ii&1) temp=(temp+aa)%nn;
        ii>>=1;
        aa=(aa+aa)%nn;
    }
    return temp;
}

LL solve1()
{
    double tmp=y*log10(x);
    tmp=tmp-(LL)tmp;
    tmp=pow(10.0,tmp);
    while(!(1000.0<=tmp && tmp<10000.0))
    {
        tmp*=10.0;
    }
    int num=(int)tmp;
    return (LL)num;
    //printf("first four numbers: %d\n",num);

    /*LL ans=1;
    for(int i=1;i<=num;i++)
    {
        ans=(ans*i)%p2;
    }
    return ans;*/
}

LL solve2(LL k)
{
    LL ans=0;
    for(int i=1;i<=n;i++)
    {
        ans=(ans+pow_mod(a[i],k,p3))%p3;
    }
    return ans;
}

int main()
{
    //clock_t start,finish;
    //start=clock();
    freopen("A_input.txt","r",stdin);
    freopen("A_output2.txt","w",stdout);
    int T;
    scanf("%d",&T);
    for(int kase=1;kase<=T;kase++)
    {
        scanf("%lld%lld",&x,&y);
        //if(y>1e9) {printf("here!\n\n\n\n\n\n\n\n\n");}
        scanf("%d",&n);
        for(int i=1;i<=n;i++)
        {
            scanf("%lld",&a[i]);
        }
        scanf("%lld%lld%lld%lld",&p1,&p2,&p3,&p4);

        LL k=solve1();
        //printf("k=%lld\n",k);
        LL ans=solve2(k);
        //printf("ans=%lld\n",ans);
        //printf("p1=%lld p4=%lld\n",p1,p4);
        ans=mul_mod(ans,p1,p4);

        printf("Case #%d: %lld\n",kase,ans);
    }
    //for(int i=1;i<=1e9;i++);
    //finish=clock();
    //printf("%d\n",finish-start);
    return 0;
}
