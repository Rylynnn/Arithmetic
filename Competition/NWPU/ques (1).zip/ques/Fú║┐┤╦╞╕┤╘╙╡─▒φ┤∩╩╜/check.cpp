#include<cstdio>
#include<cmath>
#include<ctime>
#define maxn 100000
using namespace std;

typedef long long LL;
LL x,y;
int n;
LL a[maxn+5];
LL p1,p2,p3,p4;
double Pow(double x,LL y)
{
    if(!y)return 1;
    while(x>=10)x/=10;
    double ans=1.0;
    while(y)
    {
        if(y&1)
        {
            ans*=x;
            while(ans>=10)
                ans/=10;
        }
        y>>=1;
        x*=x;
        while(x>=10)
            x/=10;
    }
    return ans;
}
LL solve1()
{
    double tmp=Pow(x,y);
    return LL(tmp*1000);
}

//int main()
//{
//    //clock_t start,finish;
//    //start=clock();
//    freopen("A_input.txt","r",stdin);
//    //freopen("A_output1.txt","w",stdout);
//    int T;
//    scanf("%d",&T);
//    //printf("%d\n",T);
//    for(int kase=1;kase<=T;kase++)
//    {
//        scanf("%lld%lld",&x,&y);
//        scanf("%d",&n);
//        for(int i=1;i<=n;i++)
//        {
//            scanf("%lld",&a[i]);
//        }
//        scanf("%lld%lld%lld%lld",&p1,&p2,&p3,&p4);
//
//        LL k=solve1();
//        //printf("k=%lld\n",k);
//
//        printf("Case #%d: %lld\n",kase,k);
//    }
//    //for(int i=1;i<=1e9;i++);
//    //finish=clock();
//    //printf("%d\n",finish-start);
//    return 0;
//}

int main()
{
    //clock_t start,finish;
    //start=clock();
    freopen("A_input.txt","r",stdin);
    freopen("A_output1.txt","w",stdout);
    int T;
    scanf("%d",&T);
    for(int kase=1;kase<=T;kase++)
    {
        scanf("%lld%lld",&x,&y);
        scanf("%d",&n);
        for(int i=1;i<=n;i++)
        {
            scanf("%lld",&a[i]);
        }
        scanf("%lld%lld%lld%lld",&p1,&p2,&p3,&p4);

        LL k=solve1();
        //printf("k=%lld\n",k);
        //LL ans=solve2(k);
        //printf("ans=%lld\n",ans);
        //printf("p1=%lld p4=%lld\n",p1,p4);
        //ans=mul_mod(ans,p1,p4);

        printf("Case #%d: %lld\n",kase,k);
    }
    //for(int i=1;i<=1e9;i++);
    //finish=clock();
    //printf("%d\n",finish-start);
    return 0;
}
