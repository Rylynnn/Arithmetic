#include <cstdio>
typedef long long LL;
int n;
LL x,y,in[100005],p1,p2,p3,p4;
LL pow_mod(LL a,LL n,LL mod)
{
	LL ans=1%mod;
	a%=mod;
	while(n)
	{
		if(n&1)
			ans=ans*a%mod;
		a=a*a%mod;
		n>>=1;
	}
	return ans;
}
LL mul_mod(LL a,LL b,LL mod)
{
	a%=mod;
	b%=mod;
	LL ans=0;
	while(b)
	{
		if(b&1)
		{
			ans+=a;
			if(ans>=mod)
				ans-=mod;
		}
		b>>=1;
		a<<=1;
		if(a>=mod)
			a-=mod;
	}
	return ans;
}
double Pow(double a,LL n)
{
	double ans=1.0;
	while(a>=10)
		a/=10;
	while(n)
	{
		if(n&1)
		{
			ans*=a;
			while(ans>=10)
				ans/=10;
		}
		n>>=1;
		a*=a;
		while(a>=10)
			a/=10;
	}
	return ans;
}
LL fact(LL x,LL mod)
{
	if(x<=1)
		return 1%mod;
	return x*fact(x-1,mod)%mod;
}
int main()
{
	freopen("F.in","r",stdin);
	freopen("F.out","w",stdout);


	int t,T;
	scanf("%d",&T);
	for(t=1;t<=T;++t)
	{
        scanf("%lld%lld%d",&x,&y,&n);
        for(int i=1;i<=n;++i)
			scanf("%lld",in+i);
		scanf("%lld%lld%lld%lld",&p1,&p2,&p3,&p4);
        LL tt=(LL)(Pow(1.0*x,y)*1000);
        tt=fact(tt,p2);
        LL ans=0;
        for(int i=1;i<=n;++i)
			(ans+=pow_mod(in[i],tt,p3))%=p3;
		ans=mul_mod(p1,ans,p4);
		printf("Case #%d: %lld\n",t,ans);
	}
	return 0;
}
/*
2
1000 1000000000
1
1000000000
10007 10007  10007 1000000007
12345 999999999
2
12345 67890
1000000007 11 13 1000000007
*/
