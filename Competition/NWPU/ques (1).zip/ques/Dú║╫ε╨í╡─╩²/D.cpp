#include<cstdio>
#include<cstring>
#include<ctime>
#define maxn 200
using namespace std;

char str[maxn+5];
int cnt[11];
char num[11][6]={"zero","one","two","three","four","five",
                "six","seven","eight","nine","minus"};

void getnum()
{
    for(int i=0;i<strlen(str);i++)
    {
        if(str[i]!='+')
        {
            char tmp[10]={0};
            int k=0;
            while(str[i]!='+'&&str[i]!=0)
            {
                tmp[k]=str[i];
                k++;
                i++;
            }
            //printf("[%s]\n",tmp);
            for(int i=0;i<11;i++)
            {
                if(strcmp(tmp,num[i])==0)
                {
                    cnt[i]++;
                    break;
                }
            }
        }
    }
}

void solve()
{
    getnum();

    int flag=0;
    for(int i=1;i<=9;i++)
    {
        if(cnt[i]!=0)
        {
            flag=1;
            break;
        }
    }

    if(!flag)
    {
        printf("0\n");
    }
    else if(cnt[10]==0)
    {
        for(int i=1;i<=9;i++)
        {
            for(int j=1;j<=cnt[i];j++)
            {
                printf("%d",i);
            }
        }
        printf("\n");
    }
    else
    {
        printf("-");
        for(int i=9;i>=0;i--)
        {
            for(int j=1;j<=cnt[i];j++)
            {
                printf("%d",i);
            }
        }
        printf("\n");
    }
}

int main()
{
    //time_t start,finish;
    //start=clock();
    freopen("D_input.txt","r",stdin);
    //freopen("B_output.txt","w",st6dout);
    int T;
    scanf("%d",&T);
    getchar();
    for(int kase=1;kase<=T;kase++)
    {
        memset(cnt,0,sizeof(cnt));
        gets(str);
        printf("Case #%d: ",kase);
        solve();
    }
    //for(int i=0;i<1e9;i++);
    //finish=clock();
    //printf("%d\n",finish-start);
    return 0;
}
