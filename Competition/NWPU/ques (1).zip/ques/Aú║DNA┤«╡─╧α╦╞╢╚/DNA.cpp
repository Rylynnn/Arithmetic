#include <cstdio>
#include <iostream>
#include <ctime>
using namespace std;

char a[1000010];
char b[1000010];

int main()
{
	clock_t start,finish;
	start=clock();
	freopen("A_in.txt","r",stdin);
	//freopen("DNAout.txt","w",stdout);
	int n, t;
    scanf("%d", &t);
    for(int kase=1;kase<=t;kase++)
    {
        scanf("%d%s%s", &n, a, b);
        long long ans = 0;
        for (int i = 0; i < n; i++)
        {
            if (a[i]=='A' && b[i]=='A')
                ans += 1513;
            else if (a[i]=='A' && b[i]=='T' || a[i]=='T' && b[i]=='A')
                ans += 666;
            else if (a[i]=='T' && b[i]=='T')
                ans += 2324;
            else if (a[i]=='T' && b[i]=='G' || a[i]=='G' && b[i]=='T')
                ans += 11;
            else if (a[i]=='T' && b[i]=='C' || a[i]=='C' && b[i]=='T')
                ans += 123;
            else if (a[i]=='G' && b[i]=='G')
                ans += 3999;
            else if (a[i]=='G' && b[i]=='C' || a[i]=='C' && b[i]=='G')
                ans += 521;
            else if (a[i]=='G' && b[i]=='A' || a[i]=='A' && b[i]=='G')
                ans += 423;
            else if (a[i]=='C' && b[i]=='C')
                ans += 4423;
            else if (a[i]=='C' && b[i]=='A' || a[i]=='A' && b[i]=='C')
                ans += 2;
        }
        cout <<"Case #"<<kase<<": "<<ans << endl;
    }
    finish=clock();
    printf("[%d]\n",finish-start);
	return 0;
}
