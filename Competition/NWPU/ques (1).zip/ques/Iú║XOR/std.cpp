#include <cstdio>
#include <map>
using namespace std;
typedef long long LL;
map<int,int>mp;
int T,n,in[1005],x;
LL ans;
int main()
{

    //freopen("in.txt","r",stdin);
    //freopen("out.txt","w",stdout);

    scanf("%d",&T);
    for(int t=1;t<=T;++t)
    {
        scanf("%d%d",&n,&x);
        for(int i=1;i<=n;++i)
            scanf("%d",in+i);
        mp.clear();
        int i,j;
        ans=0;
        mp[in[1]^in[2]]=1;
        for(i=3;i<n;++i)
        {
            for(j=i+1;j<=n;++j)
                ans+=mp[x^in[i]^in[j]];
            for(j=1;j<i;++j)
                ++mp[in[i]^in[j]];
        }
        printf("Case #%d: %lld\n",t,ans);
    }
    return 0;
}
